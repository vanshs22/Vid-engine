import type {Line, Scene, VisualPlan} from '../../types/project';
import {motionSkillsForVisual} from '../motion/capabilities';

/**
 * Deterministic sentence-to-visual director. It is deliberately provider-free:
 * an LLM or research provider can replace this later while keeping the same
 * VisualPlan artifact contract.
 */
export function directScene(line: Line, scene: Scene): VisualPlan {
  const text = line.text.toLowerCase();
  const stepIndex = scene.id.match(/\d+/) ? Math.max(0, Number(scene.id.match(/\d+/)![0]) - 1) : 0;
  if (/(how .* work|workflow|pipeline|text to speech|becomes? .* sound)/.test(text)) return plan('Explain the signal path', 'text, model, and generated voice', 'move from words through the voice model to audio', 'none', 'hook-wide', 'orb-pulse', stepIndex, 'Words become sound', 'diagram');
  if (/(turns? .* into|converts? .* into)/.test(text)) return plan('Animate text becoming sound', 'text-to-speech process', 'convert words into an audio stream', 'none', 'hook-wide', 'orb-pulse', stepIndex, 'Text becomes sound', 'process');
  if (/(compare|versus|instead of|own computer|before and after)/.test(text)) return plan('Compare the input with generated audio', 'source words and generated voice', 'transform one into the other', 'none', 'hook-wide', 'orb-pulse', stepIndex, 'From text to a voice', 'split-screen');
  if (/(pattern|rhythm|pitch|texture|learns|signal|data)/.test(text)) return plan('Visualize the voice pattern', 'voice signal', 'measure rhythm, pitch, and texture', 'none', 'object-close', 'orb-pulse', stepIndex, 'The model learns the pattern', 'data-viz');
  if (/(listen|hear|sounds?|reaction|magic|notice|finally|surpris)/.test(text)) return plan('Show the human reaction to the generated voice', 'presenter listening', 'hear the result and react', 'none', 'character-close', 'orb-pulse', stepIndex, 'That sounds real', 'reaction');
  if (/(github|website|web page|browser|dashboard|repo)/.test(text)) return plan('Show the real referenced interface', 'website or application', 'navigate and demonstrate the page', 'screen-recording', 'ui-push', 'screen-recording', stepIndex, 'Open the real screen');
  if (/(download|install|model)/.test(text)) return plan('Show a local download workflow', 'voice model', 'download the model', 'download', 'ui-push', 'download-progress', stepIndex, 'Download it once');
  if (/(record|sample|microphone)/.test(text)) return plan('Show a recording workflow', 'voice sample', 'record a short sample', 'recording', 'character-close', 'record-waveform', stepIndex, 'Clone your voice');
  if (/(accent|age|emotion|speed|design)/.test(text)) return plan('Show voice controls being tuned', 'voice settings', 'adjust voice controls', 'voice-design', 'ui-push', 'move-sliders', stepIndex, 'Design the sound');
  if (/(script|type)/.test(text)) return plan('Show the script entering the generator', 'text script', 'type words into the voice generator', 'script-editor', 'ui-push', 'generate-waveform', stepIndex, 'Write the script');
  if (/(generate|audio file)/.test(text)) return plan('Show text becoming generated audio', 'voice generator', 'generate the audio', 'generate', 'ui-push', 'generate-waveform', stepIndex, 'Type and generate');
  if (/(caption|word|timing|sync)/.test(text)) return plan('Show narration and captions aligning', 'caption timeline', 'sync words to narration', 'caption-sync', 'object-close', 'caption-timeline', stepIndex, 'Sync captions');
  if (/(permission|own|copy|yes)/.test(text)) return plan('Show a clear permission reminder', 'voice rights', 'use an allowed voice', 'permission', 'permission-wide', 'permission-reveal', stepIndex, 'Get permission');
  if (/(local|computer|free|cost|money)/.test(text)) return plan('Introduce the local voice workflow', 'local voice studio', 'run the workflow locally', 'none', stepIndex === 0 ? 'hook-wide' : 'ui-push', 'orb-pulse', stepIndex, stepIndex === 0 ? 'Voice without the bill' : 'Run it locally');
  return plan('Show the subject in its environment', scene.environment, scene.animation.join(', ') || 'explain the idea', 'none', 'hook-wide', 'orb-pulse', stepIndex, scene.description);
}

function plan(purpose: string, subject: string, action: string, uiComponent: VisualPlan['uiComponent'], camera: VisualPlan['camera'], animationPreset: VisualPlan['animationPreset'], stepIndex: number, heading: string, shotType?: VisualPlan['shotType']): VisualPlan {
  return {purpose, subject, action, uiComponent, camera, shotType: shotType ?? (camera === 'ui-push' ? 'ui-demo' : camera), animationPreset, stepIndex, heading, motionSkills: motionSkillsForVisual(uiComponent, 'voice-studio-3d')};
}

export function directSceneWithStyle(line: Line, scene: Scene, referenceStyle?: string): VisualPlan {
  const plan = directScene(line, scene);
  const renderer = scene.visualStyle === 'claude-animation' ? 'stick-story' : scene.visualStyle;
  return referenceStyle ? {...plan, referenceStyle, renderer} : {...plan, renderer};
}
