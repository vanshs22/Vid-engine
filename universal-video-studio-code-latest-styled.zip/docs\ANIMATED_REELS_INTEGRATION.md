# Animated Reels integration

## Source studied

The archive is `animated-reels.zip` from the repository main branch. The source was inspected from its template files:

- `SKILL.md`
- `src/Root.tsx`
- `src/scenes/Example.tsx`
- `src/components/primitives.tsx`
- `src/components/Captions.tsx`
- `src/anim.ts`
- `src/timeline.ts`
- `src/theme.ts`
- `src/voTiming.ts`
- `package.json`

## Reusable ideas

The archive is a Remotion-native, time-driven motion system. Its important ideas are now adapted instead of copied as a second application:

- `useCurrentFrame()` plus FPS converts each shot into deterministic local seconds.
- `p()` provides clamped eased progress windows.
- `sp()` uses Remotion spring timing for entrances.
- `track()` provides numeric keyframe interpolation.
- `typed()` supports visible typing progress.
- `RollText` provides staggered word entrances.
- `Pop` provides spring cards, chips, and notifications.
- Browser windows, charts, progress bars, diagrams, waveform bars, and comparison cards form the motion vocabulary.
- The archive's caption and VO timing files were not duplicated. Universal Video Studio continues to use `src/core/timing.ts`, `src/core/captions.ts`, and the shared `CaptionOverlay`.

## Integration boundary

The new renderer is `src/styles/motionGraphics.tsx`. It uses the existing Remotion runtime, current project timing, current nested shot Sequences, existing transitions, and the existing caption/audio layers.

The renderer supports:

- Kinetic headlines
- Word-synchronised shared captions
- Browser/application windows
- Typing cursor animation
- Animated buttons
- Progress bars
- Counters/data bars
- Process diagrams
- Floating comparison cards
- Waveforms
- Perspective CSS transforms
- Spring-like frame-driven entrances

No second animation loop, browser capture path, package runtime, or Three.js dependency was introduced.

## Renderer selection

`VisualPlan.renderer` is now the explicit renderer selection field. `ShotLayer` executes it. Existing Three.js scenes continue to use `voice-studio-3d`; motion scenes use `motion-graphics`. The Director attaches the renderer selection to generated plans, and tests cover the selection path.

## Verification project

`projects/motion-test/project.json` deliberately mixes both renderers:

- Six motion-graphics scenes
- Three Three.js scenes
- Shared narration timing
- Shared captions
- Shared music and SFX mix
- Shot-specific transitions

The output proves both renderers execute in one Remotion composition:

- `out/motion-graphics-integration-test.mp4`
- `out/motion-graphics-integration-test-contact-sheet.png`
- `out/motion-graphics-execution-report.json`
- `out/motion-graphics-timing-report.json`
- `out/motion-graphics-integration-test-qa.json`

The video includes kinetic headings, browser UI, typing, progress/waveform animation, a process transition, captions from the shared timing source, and Three.js shots in the same final composition.

## Deliberate non-copying decisions

The archive's example script, brand marks, copy, and scene order were not used. The integrated profile is stored as `warm-kinetic-typography` in `src/styles/referenceBlueprints/warm-kinetic-typography.json` and is separate from the cinematic 3D reference style.
