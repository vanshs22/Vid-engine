# SnapInsta cinematic 3D reference blueprint

**Blueprint ID:** `snapinsta-cinematic-3d`  
**Source:** `SnapInsta.to_AQMmlQfuQ0m4G6B2cLB9enjIHKWAf2sFwvlVOZRU_kLYwzBYTghj7iHR7VUDFW_tLlCmxDZ36pSFn5cslV8JH-VhtRasQpQ7Oz3Terk.mp4` on `main`  
**Blueprint file:** `src/styles/referenceBlueprints/snapinsta-cinematic-3d.json`  
**Runtime selector:** add `"referenceStyle": "snapinsta-cinematic-3d"` to a project  
**Analysis evidence:** `reference/analysis/snapinsta-to-aqmmlqfu0m4g6b2clb9enjihkwaf2sfwvlvozru-klywzb/`

## Measured evidence

The reference is 68.628 seconds, 720×1280, 30 FPS, H.264 video with 48 kHz stereo AAC. The OpenCV pass detected 33 candidate scene starts with a median duration of approximately 1.967 seconds and a detected range of 0.967–3.433 seconds. These are threshold-based visual boundaries, not semantic labels.

The analysis generated:

- `metadata.json`
- `scene-boundaries.json`
- `audio.wav`
- `audio-analysis.json`
- `contact-sheet.jpg`
- timestamped representative JPEG frames

The audio pass measures RMS and spectral centroid changes. It does not claim that a waveform-only signal is a whoosh, click, impact, narration, or music. Specific SFX identities remain low-confidence until a vision/audio model or human annotation confirms them.

## Visual language

The reference uses a vertical 9:16 cinematic 3D explainer language:

- Warm sunset orange and peach light against deep plum, violet, and magenta shadows.
- A persistent creator-studio geography with desk, laptop, window panels, and string lights.
- A stylized presenter and a small companion character. The production system must use its own characters rather than copy these designs.
- Short portrait close-ups for reaction and emphasis.
- Floating software cards in the upper-middle or upper-third of the frame.
- Strong depth separation between foreground character/object, midground UI, and blurred studio background.
- White or lavender captions with a single blue/magenta highlighted phrase.
- Rounded UI cards with compact browser chrome, strong black text, and status colors.
- Frequent returns to the character after a product/UI proof beat.

## Camera and edit language

The reference cuts quickly but gives readable UI beats. The useful production rules are:

- Hold or slowly push on environment and character shots.
- Reveal a card laterally or with a short scale entrance.
- Track focus from presenter to card, then back to presenter or result object.
- Use a pull-out after a reaction or result reveal.
- Keep readable UI cards below the safe-height limit and never let them cover the main subject without a declared reason.
- Use hard cuts for most returns to the character. Reserve directional movement for a card entering or a comparison resolving.
- Use one literal action per shot. Do not use a generic card for narration that describes a character reaction, object action, or process.

## Audio direction

The saved blueprint specifies a continuous modern electronic bed with warm pads, per-shot intensity changes, narration ducking, and intro/outro fades. It permits only event-anchored UI clicks, reveal risers, result impacts, and visible character/object foley. It explicitly rejects a repeated whoosh at every boundary and rejects claiming a specific SFX identity when the evidence is insufficient.

## Runtime proof

The sample project now selects this blueprint and renders it with the existing project characters and original UI content. The final sample was rendered to:

- `out/final.mp4`
- `out/contact-sheet.png`
- `out/storyboard.json`
- `out/shot-timeline.json`
- `out/overlay-timeline.json`
- `out/sound-effect-timeline.json`
- `out/music-automation-report.json`
- `out/audio-mix-report.json`
- `out/visual-qa-report.json`

The render uses the blueprint's warm sunset/purple window treatment, tracked camera movement, compact UI cards, original robot presenter, original script, and event-driven local audio. It does not insert reference frames or reuse the reference characters.
