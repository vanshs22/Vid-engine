import type {Project} from '../types/project';
import type {Timing, LineTiming, WordTiming} from './timing';

export type ValidationIssue = {path: string; message: string};

export function validateTimingForProject(project: Project, timing: Timing): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const projectLineIds = new Set(project.lines.map((line) => line.id));
  const lineTimings = new Map<string, LineTiming>();
  const seenTimingLineIds = new Set<string>();
  for (const lineTiming of timing.lines) {
    if (seenTimingLineIds.has(lineTiming.lineId)) issues.push({path: `timing.lines.${lineTiming.lineId}`, message: 'Duplicate line timing'});
    seenTimingLineIds.add(lineTiming.lineId);
    lineTimings.set(lineTiming.lineId, lineTiming);
  }

  if (timing.lines.length !== project.lines.length) {
    issues.push({path: 'timing.lines', message: `Expected ${project.lines.length} line timings, received ${timing.lines.length}`});
  }

  for (const line of project.lines) {
    const lineTiming = lineTimings.get(line.id);
    if (!lineTiming) {
      issues.push({path: `timing.lines.${line.id}`, message: 'Missing line timing'});
      continue;
    }
    if (lineTiming.text !== line.text) issues.push({path: `timing.lines.${line.id}.text`, message: 'Timing text does not match project text'});
    if (lineTiming.lineIndex !== project.lines.indexOf(line)) issues.push({path: `timing.lines.${line.id}.lineIndex`, message: 'Timing line index does not match project order'});
    if (lineTiming.endSeconds <= lineTiming.startSeconds) issues.push({path: `timing.lines.${line.id}`, message: 'End must be after start'});
    if (lineTiming.endSeconds > timing.durationSeconds) issues.push({path: `timing.lines.${line.id}`, message: 'Line ends after timing duration'});
  }

  for (const lineTiming of timing.lines) {
    if (!projectLineIds.has(lineTiming.lineId)) issues.push({path: `timing.lines.${lineTiming.lineId}`, message: 'Unknown line ID'});
  }

  let previousStart = -Infinity;
  for (const lineTiming of timing.lines) {
    if (lineTiming.startSeconds < previousStart) issues.push({path: `timing.lines.${lineTiming.lineId}`, message: 'Line timing is not monotonic'});
    previousStart = lineTiming.startSeconds;
  }

  const wordsByLine = new Map<string, WordTiming[]>();
  for (const word of timing.words) {
    if (!projectLineIds.has(word.lineId)) {
      issues.push({path: `timing.words.${word.text}`, message: 'Unknown line ID'});
      continue;
    }
    if (word.endSeconds < word.startSeconds) issues.push({path: `timing.words.${word.text}`, message: 'End must not be before start'});
    if (word.endSeconds > timing.durationSeconds) issues.push({path: `timing.words.${word.text}`, message: 'Word ends after timing duration'});
    if (word.lineIndex !== project.lines.findIndex((line) => line.id === word.lineId)) issues.push({path: `timing.words.${word.text}`, message: 'Word line index does not match project order'});
    const words = wordsByLine.get(word.lineId) ?? [];
    words.push(word);
    wordsByLine.set(word.lineId, words);
  }

  for (const [lineId, words] of wordsByLine) {
    let previousWordStart = -Infinity;
    for (const word of words) {
      if (word.startSeconds < previousWordStart) issues.push({path: `timing.words.${lineId}`, message: 'Word timing is not monotonic'});
      previousWordStart = word.startSeconds;
    }
  }

  if (!timing.estimated) {
    for (const line of project.lines) {
      if ((wordsByLine.get(line.id) ?? []).length === 0) issues.push({path: `timing.words.${line.id}`, message: 'Non-estimated timing must contain words for every line'});
    }
  }

  if (timing.durationSeconds < Math.max(...timing.lines.map((line) => line.endSeconds), 0)) {
    issues.push({path: 'timing.durationSeconds', message: 'Duration does not cover all line timings'});
  }

  return issues;
}

function validateShotTimelines(project: Project, timing: Timing): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const tolerance = 1 / project.format.fps + 0.002;
  for (const scene of project.scenes) {
    const shots = scene.shotTimeline;
    if (!shots?.length) continue;
    const lineIndex = project.lines.findIndex((line) => line.id === scene.lineId);
    const lineTiming = timing.lines.find((line) => line.lineId === scene.lineId);
    if (!lineTiming || lineIndex < 0) continue;
    const nextLine = timing.lines[lineIndex + 1];
    const sceneDuration = (nextLine?.startSeconds ?? timing.durationSeconds) - lineTiming.startSeconds;
    if (Math.abs(shots[0].startSeconds) > tolerance) issues.push({path: `scenes.${scene.id}.shotTimeline`, message: 'Shot timeline must start at zero'});
    for (let index = 0; index < shots.length; index += 1) {
      const shot = shots[index];
      if (index > 0 && Math.abs(shot.startSeconds - shots[index - 1].endSeconds) > tolerance) issues.push({path: `scenes.${scene.id}.shotTimeline.${shot.id}`, message: 'Shot timeline contains a gap or overlap'});
      if (shot.endSeconds > sceneDuration + tolerance) issues.push({path: `scenes.${scene.id}.shotTimeline.${shot.id}`, message: 'Shot ends after its scene window'});
      for (const event of shot.audioEvents) {
        if (!event.atWord) continue;
        const match = timing.words.find((word) => word.lineId === scene.lineId && normalizeToken(word.text) === normalizeToken(event.atWord!));
        if (!match) issues.push({path: `scenes.${scene.id}.shotTimeline.${shot.id}.audioEvents`, message: `Audio event word anchor not found: ${event.atWord}`});
        else {
          const relativeWordStart = match.startSeconds - lineTiming.startSeconds;
          if (relativeWordStart < shot.startSeconds - tolerance || relativeWordStart > shot.endSeconds + tolerance) issues.push({path: `scenes.${scene.id}.shotTimeline.${shot.id}.audioEvents`, message: `Audio event word anchor falls outside shot: ${event.atWord}`});
        }
      }
    }
    const last = shots[shots.length - 1];
    if (Math.abs(last.endSeconds - sceneDuration) > tolerance) issues.push({path: `scenes.${scene.id}.shotTimeline`, message: `Shot timeline must end at the scene window (${sceneDuration.toFixed(3)}s)`});
  }
  return issues;
}

function validateCaptionAnchors(project: Project, timing: Timing): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  for (const line of project.lines) {
    const words = timing.words.filter((word) => word.lineId === line.id);
    let searchFrom = 0;
    for (const chunk of line.caption.split('|').map((value) => value.trim()).filter(Boolean)) {
      const first = chunk.split(/\s+/).find(Boolean)?.replace(/^\*/, '').toLowerCase().replace(/[^a-z0-9]/g, '') ?? '';
      const matchIndex = words.findIndex((word, index) => index >= searchFrom && normalizeToken(word.text).startsWith(first));
      if (matchIndex < 0) issues.push({path: `lines.${line.id}.caption`, message: `Caption anchor not found: ${first}`});
      else searchFrom = matchIndex + 1;
    }
  }
  return issues;
}

function normalizeToken(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function validateProjectSemantics(project: Project, timing: Timing): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const sceneIds = new Set(project.scenes.map((scene) => scene.id));
  const lineIds = new Set(project.lines.map((line) => line.id));

  project.lines.forEach((line, index) => {
    if (!sceneIds.has(line.sceneId)) issues.push({path: `lines.${index}.sceneId`, message: `Unknown scene ${line.sceneId}`});
    const lineWords = timing.words.filter((word) => word.lineId === line.id);
    if (lineWords.length === 0) issues.push({path: `lines.${index}.text`, message: 'Line has no timed words'});
  });

  project.scenes.forEach((scene, index) => {
    if (!lineIds.has(scene.lineId)) issues.push({path: `scenes.${index}.lineId`, message: `Unknown line ${scene.lineId}`});
  });

  for (let index = 1; index < timing.lines.length; index += 1) {
    if (timing.lines[index].startSeconds < timing.lines[index - 1].startSeconds) {
      issues.push({path: `timing.lines.${index}`, message: 'Line timing is not monotonic'});
    }
  }

  if (timing.durationSeconds > project.targetDurationSeconds * 1.5) {
    issues.push({path: 'timing.durationSeconds', message: 'Estimated duration is more than 50% above the target'});
  }

  return [...validateTimingForProject(project, timing), ...validateShotTimelines(project, timing), ...validateCaptionAnchors(project, timing), ...issues];
}
