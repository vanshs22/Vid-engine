import {describe, expect, it} from 'vitest';
import {estimateTiming} from '../../src/core/timing';
import {validateProjectSemantics} from '../../src/core/validation';
import {parseProject} from '../../src/types/project';

function makeProject() {
  return parseProject({
    id: 'test',
    title: 'Test',
    format: {width: 1080, height: 1920, fps: 30},
    targetDurationSeconds: 10,
    style: 'inside-out',
    voice: {provider: 'estimated', name: 'am_michael', speed: 1},
    music: {mode: 'none'},
    lines: [{id: 'l1', text: 'Hello world.', caption: 'HELLO *WORLD', sceneId: 's1', gapSeconds: 0.3}],
    scenes: [{id: 's1', lineId: 'l1', visualStyle: 'inside-out', description: 'Hello', environment: 'room', camera: {preset: 'push'}, animation: [], transition: 'cut', audioCues: []}],
    sources: [],
  });
}

describe('project validation', () => {
  it('accepts a connected project', () => {
    const project = makeProject();
    expect(validateProjectSemantics(project, estimateTiming(project))).toEqual([]);
  });

  it('reports an unconnected scene reference', () => {
    const project = makeProject();
    const broken = {...project, lines: [{...project.lines[0], sceneId: 'missing'}]};
    const issues = validateProjectSemantics(broken, estimateTiming(broken));
    expect(issues.some((issue) => issue.message.includes('Unknown scene'))).toBe(true);
  });

  it('rejects a shot timeline that does not cover its scene window', () => {
    const project = makeProject();
    const shot = {
      id: 'shot-1', startSeconds: 0, endSeconds: 0.2, shotType: 'hook-wide' as const,
      camera: {movement: 'hold' as const, target: 'studio', from: 'studio', to: 'studio', preset: 'hook-wide' as const},
      subjectMovement: 'holds', objectAnimation: 'pulses',
      overlay: {entrance: 'cut' as const, exit: 'cut' as const, maxHeightPercent: 10},
      focus: {from: 'studio', to: 'studio'}, transition: 'cut' as const, audioEvents: [], music: {intensity: 0.5, duckingDb: 8},
    };
    const withShot = parseProject({...project, scenes: [{...project.scenes[0], shotTimeline: [shot]}]});
    const issues = validateProjectSemantics(withShot, estimateTiming(withShot));
    expect(issues.some((issue) => issue.message.includes('must end at the scene window'))).toBe(true);
  });

  it('rejects a caption anchor that is not spoken', () => {
    const project = makeProject();
    const broken = {...project, lines: [{...project.lines[0], caption: 'NOT SPOKEN'}]};
    const issues = validateProjectSemantics(broken, estimateTiming(broken));
    expect(issues.some((issue) => issue.message.includes('Caption anchor not found'))).toBe(true);
  });
});
