import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Scene, ShotTimelineSegment, VisualPlan} from '../types/project';

const C = {
  bg: '#FAF9F5',
  ink: '#171716',
  muted: '#8C8A82',
  line: '#E8E6DC',
  orange: '#D97757',
  orangeSoft: '#F6E3D9',
  blue: '#3568D4',
  green: '#4E9A5B',
  card: '#FFFFFF',
};

export function MotionGraphicsScene({scene, shot, durationInFrames}: {scene: Scene; shot?: ShotTimelineSegment; durationInFrames?: number}) {
  const frame = useCurrentFrame();
  const {durationInFrames: compositionDuration, fps} = useVideoConfig();
  const duration = Math.max(2, durationInFrames ?? compositionDuration);
  const progress = interpolate(frame, [0, duration - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const plan = scene.visualPlan;
  const shotType = shot?.shotType ?? plan?.shotType ?? 'hook-wide';
  const heading = shot?.heading ?? plan?.heading ?? scene.description;
  const enter = spring({frame, fps, config: {damping: 18, stiffness: 150, mass: 0.8}});

  return <AbsoluteFill style={{background: C.bg, color: C.ink, fontFamily: 'Arial, sans-serif', overflow: 'hidden'}}>
    <WarmBackground progress={progress} />
    {shotType === 'ui-demo' ? <BrowserWindow title={heading} progress={progress} uiComponent={shot?.uiComponent ?? plan?.uiComponent ?? 'none'} /> : null}
    {shotType === 'data-viz' ? <DataPanel heading={heading} progress={progress} /> : null}
    {shotType === 'diagram' || shotType === 'process' ? <ProcessPanel heading={heading} progress={progress} /> : null}
    {shotType === 'split-screen' ? <ComparisonPanel heading={heading} progress={progress} /> : null}
    {shotType === 'object-close' ? <WavePanel heading={heading} progress={progress} /> : null}
    {shotType !== 'ui-demo' && shotType !== 'data-viz' && shotType !== 'diagram' && shotType !== 'process' && shotType !== 'split-screen' && shotType !== 'object-close' ? <KineticHeading heading={heading} progress={progress} /> : null}
    <div style={{position: 'absolute', left: 72, right: 72, bottom: 350, height: 5, background: '#E7E1D7', transform: `scaleX(${enter})`, transformOrigin: 'left'}}><div style={{height: '100%', width: `${Math.round(progress * 100)}%`, background: C.orange}} /></div>
  </AbsoluteFill>;
}

function WarmBackground({progress}: {progress: number}) {
  const shift = Math.sin(progress * Math.PI * 2) * 8;
  return <>
    <AbsoluteFill style={{background: `radial-gradient(circle at ${28 + shift}% 24%, rgba(217,119,87,0.23), transparent 35%), radial-gradient(circle at 76% 78%, rgba(53,104,212,0.13), transparent 34%)`}} />
    <div style={{position: 'absolute', top: 140, left: 80, right: 80, height: 3, background: C.ink, opacity: 0.08}} />
    <div style={{position: 'absolute', top: 170, left: 80, fontSize: 18, fontWeight: 800, letterSpacing: 4, color: C.orange}}>WARM KINETIC TYPOGRAPHY</div>
  </>;
}

function KineticHeading({heading, progress}: {heading: string; progress: number}) {
  const words = heading.split(/\s+/).filter(Boolean);
  const revealProgress = Math.max(0.18, progress);
  return <div style={{position: 'absolute', left: 72, right: 72, top: 520, textAlign: 'center'}}>{words.map((word, index) => <span key={`${word}-${index}`} style={{display: 'inline-block', margin: '0 8px', fontFamily: 'Georgia, serif', fontSize: 78, fontWeight: 700, transform: `translateY(${(1 - interpolate(revealProgress, [index * 0.08, Math.min(1, index * 0.08 + 0.3)], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})) * 80}px)`, opacity: interpolate(revealProgress, [index * 0.08, Math.min(1, index * 0.08 + 0.25)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), color: index === words.length - 1 ? C.orange : C.ink}}>{word}</span>)}</div>;
}

function BrowserWindow({title, progress, uiComponent}: {title: string; progress: number; uiComponent: VisualPlan['uiComponent']}) {
  const typed = Math.min(1, progress * 1.7);
  return <div style={{position: 'absolute', left: 90, right: 90, top: 360, height: 820, background: C.card, borderRadius: 28, border: `1px solid ${C.line}`, boxShadow: '0 30px 90px rgba(70,45,25,.18)', transform: `perspective(1400px) rotateX(${(1 - progress) * 5}deg) translateY(${(1 - progress) * 48}px)`, opacity: interpolate(progress, [0, 0.18], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), overflow: 'hidden'}}>
    <div style={{height: 68, display: 'flex', alignItems: 'center', justifyContent: 'center', borderBottom: `1px solid ${C.line}`, color: C.muted, fontWeight: 700, fontSize: 22}}><div style={{position: 'absolute', left: 28, display: 'flex', gap: 10}}>{['#FF5F57','#FEBC2E','#28C840'].map((color) => <i key={color} style={{width: 16, height: 16, borderRadius: 99, background: color}} />)}</div>{title}</div>
    <div style={{padding: 48}}><div style={{fontFamily: 'Georgia, serif', fontSize: 54, fontWeight: 700, marginBottom: 30}}>{title}</div><div style={{height: 150, borderRadius: 18, background: '#F3F5FA', padding: 28, fontFamily: 'monospace', fontSize: 28, color: C.ink}}>{uiComponent === 'script-editor' || uiComponent === 'generate' ? <>The signal becomes a controlled sound.<br /><span style={{color: C.orange}}>{'▌'.repeat(Math.max(1, Math.round(typed * 8)))}</span></> : 'Analyzing the incoming signal...'}</div><div style={{display: 'flex', gap: 18, marginTop: 34}}><div style={{flex: 1, height: 90, borderRadius: 16, background: C.orange, color: '#fff', display: 'grid', placeItems: 'center', fontSize: 25, fontWeight: 800, transform: `scale(${0.94 + typed * 0.06})`}}>Generate</div><div style={{flex: 1, height: 90, borderRadius: 16, background: '#EEF0F6', display: 'grid', placeItems: 'center', fontSize: 25, fontWeight: 800}}>Export</div></div><div style={{marginTop: 40, height: 52, borderRadius: 99, background: '#E8E6DC', overflow: 'hidden'}}><div style={{width: `${typed * 100}%`, height: '100%', background: C.blue, transition: 'none'}} /></div></div>
  </div>;
}

function ProcessPanel({heading, progress}: {heading: string; progress: number}) {
  const nodes = ['Input', 'Model', 'Result'];
  return <div style={{position: 'absolute', left: 72, right: 72, top: 540}}><h1 style={{fontFamily: 'Georgia, serif', fontSize: 68, textAlign: 'center', margin: 0}}>{heading}</h1><div style={{display: 'flex', alignItems: 'center', marginTop: 100}}>{nodes.map((node, index) => <div key={node} style={{display: 'flex', alignItems: 'center', flex: index < nodes.length - 1 ? 1 : undefined}}><div style={{width: 210, height: 150, borderRadius: 28, background: index === 1 ? C.orange : '#fff', color: index === 1 ? '#fff' : C.ink, border: `2px solid ${index === 1 ? C.orange : C.line}`, display: 'grid', placeItems: 'center', fontSize: 30, fontWeight: 800, boxShadow: '0 20px 50px rgba(70,45,25,.12)', transform: `translateY(${Math.sin(progress * Math.PI + index) * 8}px)`}}>{node}</div>{index < nodes.length - 1 ? <div style={{height: 6, flex: 1, margin: '0 18px', background: `linear-gradient(90deg, ${C.blue}, ${C.orange})`, transform: `scaleX(${Math.min(1, progress * 1.4)})`, transformOrigin: 'left'}} /> : null}</div>)}</div></div>;
}

function DataPanel({heading, progress}: {heading: string; progress: number}) {
  const values = [0.34, 0.52, 0.81, 0.46, 0.7, 0.58];
  return <div style={{position: 'absolute', left: 80, right: 80, top: 440}}><h1 style={{fontFamily: 'Georgia, serif', fontSize: 64, margin: '0 0 70px', textAlign: 'center'}}>{heading}</h1><div style={{height: 470, display: 'flex', alignItems: 'end', gap: 24, padding: '0 40px 36px', borderBottom: `3px solid ${C.ink}`}}>{values.map((value, index) => <div key={index} style={{flex: 1, height: `${(0.25 + value * Math.min(1, progress * 1.4)) * 100}%`, background: index % 2 ? C.orange : C.blue, borderRadius: '18px 18px 0 0', boxShadow: '0 12px 24px rgba(70,45,25,.14)'}} />)}</div><div style={{display: 'flex', justifyContent: 'space-between', marginTop: 24, color: C.muted, fontSize: 22}}><span>Low</span><span>Measured signal</span><span>High</span></div></div>;
}

function ComparisonPanel({heading, progress}: {heading: string; progress: number}) {
  return <div style={{position: 'absolute', left: 60, right: 60, top: 500, perspective: 1400}}><h1 style={{fontFamily: 'Georgia, serif', fontSize: 62, textAlign: 'center'}}>{heading}</h1><div style={{display: 'flex', gap: 18, marginTop: 70, transform: `translateX(${(1 - progress) * 160}px)`}}>{['BEFORE', 'AFTER'].map((label, index) => <div key={label} style={{flex: 1, height: 470, borderRadius: 26, background: index === 0 ? '#282536' : '#FFF', color: index === 0 ? '#fff' : C.ink, padding: 34, boxSizing: 'border-box', boxShadow: '0 24px 70px rgba(70,45,25,.14)', transform: `rotateY(${(index ? -1 : 1) * (1 - progress) * 10}deg)`}}><div style={{fontSize: 24, fontWeight: 900, letterSpacing: 3}}>{label}</div><div style={{marginTop: 100, height: 10, background: index === 0 ? '#FF6A5C' : C.blue, transform: `scaleX(${index === 0 ? 1 : Math.min(1, progress * 1.3)})`, transformOrigin: 'left'}} /><div style={{marginTop: 60, fontFamily: 'Georgia, serif', fontSize: 42}}>{index === 0 ? 'Noise' : 'Quiet'}</div></div>)}</div></div>;
}

function WavePanel({heading, progress}: {heading: string; progress: number}) {
  return <div style={{position: 'absolute', left: 80, right: 80, top: 500, textAlign: 'center'}}><h1 style={{fontFamily: 'Georgia, serif', fontSize: 64}}>{heading}</h1><div style={{height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 80}}>{Array.from({length: 36}, (_, index) => <i key={index} style={{width: 8, height: 30 + Math.abs(Math.sin(index * 1.8 + progress * 12)) * 180 * (0.35 + progress * 0.65), background: index % 2 ? C.orange : C.blue, borderRadius: 9}} />)}</div></div>;
}
