import {describe, expect, it} from 'vitest';
import {directScene, directSceneWithStyle} from '../../src/engines/story/director';
import {parseProject} from '../../src/types/project';

const base = parseProject({
  id: 'director-test', title: 'Director', format: {width: 1080, height: 1920, fps: 30}, targetDurationSeconds: 10,
  style: 'voice-studio-3d', voice: {provider: 'estimated', name: 'am_michael', speed: 1}, music: {mode: 'none'},
  lines: [{id: 'l1', text: 'Download the application.', caption: 'DOWNLOAD IT', sceneId: 's1', gapSeconds: 0.2}],
  scenes: [{id: 's1', lineId: 'l1', visualStyle: 'voice-studio-3d', description: 'Workflow', environment: 'studio', camera: {preset: 'push'}, animation: [], transition: 'cut', audioCues: []}],
  sources: [],
});

function directed(text: string) {
  return directScene({...base.lines[0], text}, base.scenes[0]);
}

describe('sentence-to-visual director', () => {
  it('selects a download UI for download narration', () => {
    expect(directed('Download the application.').uiComponent).toBe('download');
    expect(directed('Download the application.').shotType).toBe('ui-demo');
  });

  it('selects permission visuals for rights language', () => {
    expect(directed('Use only a voice you own or have permission to use.').uiComponent).toBe('permission');
    expect(directed('Use only a voice you own or have permission to use.').shotType).toBe('permission-wide');
  });

  it('directs the requested non-template shot types', () => {
    expect(directed('Here is how text to speech works.').shotType).toBe('diagram');
    expect(directed('The system converts each word into sound.').shotType).toBe('process');
    expect(directed('Compare the source words with the generated voice.').shotType).toBe('split-screen');
    expect(directed('The model learns rhythm, pitch, and texture.').shotType).toBe('data-viz');
    expect(directed('Listen to the result.').shotType).toBe('reaction');
    expect(directed('Watch the microphone capture a sample.').shotType).toBe('character-close');
    expect(directed('Sync every word to the audio.').shotType).toBe('object-close');
  });
  it('attaches a selected reference blueprint to generated plans', () => {
    expect(directSceneWithStyle(base.lines[0], base.scenes[0], 'snapinsta-cinematic-3d').referenceStyle).toBe('snapinsta-cinematic-3d');
    expect(directSceneWithStyle(base.lines[0], {...base.scenes[0], visualStyle: 'motion-graphics'}, 'warm-kinetic-typography').renderer).toBe('motion-graphics');
  });
});
