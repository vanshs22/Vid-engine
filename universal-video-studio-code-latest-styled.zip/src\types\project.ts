import {z} from 'zod';

const FormatSchema = z.object({
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  fps: z.number().int().positive(),
});

const VoiceSchema = z.object({
  provider: z.enum(['estimated', 'kokoro-onnx', 'recording']).default('estimated'),
  name: z.string().default('am_michael'),
  speed: z.number().positive().default(1),
});

const ShotTypeSchema = z.enum(['hook-wide', 'character-close', 'ui-demo', 'object-close', 'reaction', 'diagram', 'permission-wide', 'split-screen', 'data-viz', 'process']);
const CameraPresetSchema = z.enum(['hook-wide', 'ui-push', 'character-close', 'object-close', 'permission-wide']);
const TransitionSchema = z.enum(['cut', 'fade', 'crossfade', 'flash', 'slide', 'zoom']);

const AudioEventSchema = z.object({
  type: z.string().min(1),
  category: z.enum(['ui', 'movement', 'reveal', 'character', 'texture']).default('texture'),
  sourceAsset: z.string().min(1),
  atWord: z.string().min(1).optional(),
  timestampSeconds: z.number().nonnegative().optional(),
  durationSeconds: z.number().positive().default(0.35),
  volume: z.number().nonnegative().max(2).default(0.5),
  fadeInSeconds: z.number().nonnegative().default(0.01),
  fadeOutSeconds: z.number().nonnegative().default(0.08),
  reason: z.string().min(1),
});

const ShotTimelineSchema = z.object({
  id: z.string().min(1),
  startSeconds: z.number().nonnegative(),
  endSeconds: z.number().positive(),
  shotType: ShotTypeSchema,
  uiComponent: z.enum(['none', 'download', 'recording', 'voice-design', 'generate', 'script-editor', 'caption-sync', 'permission', 'screen-recording']).optional(),
  heading: z.string().min(1).optional(),
  objectKind: z.enum(['microphone', 'headphones', 'waveform', 'orb', 'ui']).default('orb'),
  objectLabel: z.string().min(1).optional(),
  camera: z.object({
    movement: z.enum(['hold', 'push-in', 'pull-out', 'pan-left', 'pan-right', 'reveal']),
    target: z.string().min(1),
    from: z.string().min(1),
    to: z.string().min(1),
    preset: CameraPresetSchema,
  }),
  subjectMovement: z.string().min(1),
  objectAnimation: z.string().min(1),
  overlay: z.object({
    entrance: z.enum(['cut', 'fade', 'rise', 'scale']),
    exit: z.enum(['cut', 'fade', 'drop']),
    maxHeightPercent: z.number().positive().max(100),
  }),
  focus: z.object({from: z.string().min(1), to: z.string().min(1)}),
  transition: TransitionSchema.default('cut'),
  audioEvents: z.array(AudioEventSchema).default([]),
  music: z.object({intensity: z.number().min(0).max(1), duckingDb: z.number().nonnegative().max(18)}),
}).superRefine((shot, context) => {
  if (shot.endSeconds <= shot.startSeconds) context.addIssue({code: z.ZodIssueCode.custom, path: ['endSeconds'], message: 'Shot end must be after shot start'});
});

export const VisualPlanSchema = z.object({
  purpose: z.string().min(1),
  subject: z.string().min(1),
  action: z.string().min(1),
  uiComponent: z.enum(['none', 'download', 'recording', 'voice-design', 'generate', 'script-editor', 'caption-sync', 'permission', 'screen-recording']),
  shotType: ShotTypeSchema,
  camera: CameraPresetSchema,
  animationPreset: z.enum(['orb-pulse', 'download-progress', 'record-waveform', 'move-sliders', 'generate-waveform', 'caption-timeline', 'permission-reveal', 'screen-recording']),
  stepIndex: z.number().int().nonnegative(),
  heading: z.string().min(1),
  motionSkills: z.array(z.string()).default([]),
  referenceStyle: z.string().min(1).optional(),
  renderer: z.enum(['inside-out', 'three-proof', 'stick-story', 'voice-studio', 'voice-studio-3d', 'motion-graphics']).optional(),
});

const SceneSchema = z.object({
  id: z.string().min(1),
  lineId: z.string().min(1),
  visualStyle: z.enum(['inside-out', 'three-proof', 'stick-story', 'claude-animation', 'voice-studio', 'voice-studio-3d', 'motion-graphics']),
  description: z.string().min(1),
  environment: z.string().min(1),
  camera: z.object({preset: z.string().min(1)}),
  animation: z.array(z.string()).default([]),
  transition: TransitionSchema.default('cut'),
  audioCues: z.array(z.object({type: z.string(), atWord: z.string().optional()})).default([]),
  shotTimeline: z.array(ShotTimelineSchema).optional(),
  screenRecording: z.object({
    url: z.string().url(),
    assetPath: z.string().min(1).optional(),
    actions: z.array(z.object({type: z.enum(['click', 'fill', 'press', 'wait']), selector: z.string().optional(), value: z.string().optional(), key: z.string().optional(), milliseconds: z.number().int().positive().optional()})).default([]),
    durationSeconds: z.number().positive().default(5),
  }).optional(),
  assets: z.object({characterModelPath: z.string().min(1).optional(), environmentModelPath: z.string().min(1).optional()}).optional(),
  visualPlan: VisualPlanSchema.optional(),
});

const LineSchema = z.object({
  id: z.string().min(1),
  text: z.string().min(1),
  caption: z.string().min(1),
  sceneId: z.string().min(1),
  gapSeconds: z.number().nonnegative().default(0.3),
});

export const MusicSchema = z.object({
  mode: z.enum(['none', 'procedural', 'file']).default('none'),
  path: z.string().min(1).optional(),
  mood: z.enum(['warm-tech', 'cinematic', 'calm', 'urgent']).default('warm-tech'),
  introSeconds: z.number().nonnegative().default(0.8),
  outroSeconds: z.number().nonnegative().default(1.2),
  targetLufs: z.number().finite().default(-18),
  duckingDb: z.number().nonnegative().max(18).default(8),
}).superRefine((music, context) => {
  if (music.mode === 'file' && !music.path) context.addIssue({code: z.ZodIssueCode.custom, path: ['path'], message: 'A file music path is required when music mode is file'});
});

const ProjectBaseSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  format: FormatSchema,
  targetDurationSeconds: z.number().positive(),
  captionStyle: z.enum(['word-by-word', 'phrase', 'cinematic', 'minimal']).default('phrase'),
  style: z.string().min(1),
  referenceStyle: z.string().min(1).optional(),
  voice: VoiceSchema,
  music: MusicSchema,
  lines: z.array(LineSchema).min(1),
  scenes: z.array(SceneSchema).min(1),
  sources: z.array(z.object({label: z.string(), url: z.string().url()})).default([]),
});

export const ProjectSchema = ProjectBaseSchema.superRefine((project, context) => {
  const lineIds = new Set(project.lines.map((line) => line.id));
  const sceneIds = new Set(project.scenes.map((scene) => scene.id));
  if (lineIds.size !== project.lines.length) context.addIssue({code: z.ZodIssueCode.custom, path: ['lines'], message: 'Line IDs must be unique'});
  if (sceneIds.size !== project.scenes.length) context.addIssue({code: z.ZodIssueCode.custom, path: ['scenes'], message: 'Scene IDs must be unique'});
  if (project.lines.length !== project.scenes.length) context.addIssue({code: z.ZodIssueCode.custom, path: ['scenes'], message: 'The MVP requires exactly one scene per line'});
  for (const line of project.lines) {
    const matchingScenes = project.scenes.filter((scene) => scene.lineId === line.id);
    if (matchingScenes.length !== 1) context.addIssue({code: z.ZodIssueCode.custom, path: ['lines'], message: `Line ${line.id} must have exactly one scene`});
    if (!sceneIds.has(line.sceneId)) context.addIssue({code: z.ZodIssueCode.custom, path: ['lines'], message: `Line ${line.id} references unknown scene ${line.sceneId}`});
    if (matchingScenes[0] && matchingScenes[0].id !== line.sceneId) context.addIssue({code: z.ZodIssueCode.custom, path: ['lines'], message: `Line ${line.id} sceneId does not match its scene lineId`});
    const timeline = matchingScenes[0]?.shotTimeline;
    if (timeline && timeline[0]?.startSeconds !== 0) context.addIssue({code: z.ZodIssueCode.custom, path: ['scenes'], message: `Scene ${line.sceneId} shot timeline must start at zero`});
    if (timeline && timeline.some((shot, index) => index > 0 && shot.startSeconds !== timeline[index - 1].endSeconds)) context.addIssue({code: z.ZodIssueCode.custom, path: ['scenes'], message: `Scene ${line.sceneId} shot timeline contains a gap`});
  }
});

export type Project = z.infer<typeof ProjectSchema>;
export type VisualPlan = z.infer<typeof VisualPlanSchema>;
export type Line = Project['lines'][number];
export type Scene = Project['scenes'][number];
export type ShotTimelineSegment = NonNullable<Scene['shotTimeline']>[number];

export function parseProject(input: unknown): Project {
  return ProjectSchema.parse(input);
}
