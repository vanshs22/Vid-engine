import snapinstaBlueprint from './referenceBlueprints/snapinsta-cinematic-3d.json';

export type ReferenceStyleBlueprint = typeof snapinstaBlueprint;

export const referenceStyleProfiles: Record<string, ReferenceStyleBlueprint> = {
  [snapinstaBlueprint.id]: snapinstaBlueprint,
};

export function getReferenceStyleProfile(id?: string): ReferenceStyleBlueprint | undefined {
  return id ? referenceStyleProfiles[id] : undefined;
}

export function isReferenceStyle(id: string | undefined, expected: string): boolean {
  return Boolean(id && getReferenceStyleProfile(id)?.id === expected);
}
