from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import ReferenceFeedback


class ReferenceLibrary:
    """File-backed reference blueprint library for local-first review workflows."""

    def __init__(self, root: Path):
        self.root = root
        self.blueprint_dir = root / "src/styles/referenceBlueprints"
        self.feedback_path = root / "projects/reference-style-feedback.json"

    def list(self) -> list[dict[str, Any]]:
        result = []
        for path in sorted(self.blueprint_dir.glob("*.json")):
            blueprint = json.loads(path.read_text())
            result.append(self._summary(blueprint, path))
        return result

    def get(self, reference_id: str) -> dict[str, Any] | None:
        for path in self.blueprint_dir.glob("*.json"):
            blueprint = json.loads(path.read_text())
            if blueprint.get("id") == reference_id:
                return {**self._summary(blueprint, path), "blueprint": blueprint, "feedback": self._feedback().get(reference_id, [])}
        return None

    def add_feedback(self, reference_id: str, feedback: ReferenceFeedback) -> dict[str, Any]:
        if self.get(reference_id) is None:
            raise KeyError(reference_id)
        data = self._feedback()
        entry = feedback.model_dump(mode="json")
        entry["saved_at"] = datetime.now(timezone.utc).isoformat()
        data.setdefault(reference_id, []).append(entry)
        self.feedback_path.parent.mkdir(parents=True, exist_ok=True)
        self.feedback_path.write_text(json.dumps(data, indent=2) + "\n")
        return entry

    def _feedback(self) -> dict[str, list[dict[str, Any]]]:
        if not self.feedback_path.exists():
            return {}
        return json.loads(self.feedback_path.read_text())

    @staticmethod
    def _summary(blueprint: dict[str, Any], path: Path) -> dict[str, Any]:
        return {"id": blueprint["id"], "name": blueprint.get("name", blueprint["id"]), "version": blueprint.get("version", 1), "path": str(path), "sourceReference": blueprint.get("sourceReference"), "confidence": min((item.get("confidence", 1.0) for item in blueprint.get("confidenceNotes", [])), default=1.0)}
