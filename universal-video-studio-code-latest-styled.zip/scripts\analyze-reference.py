#!/usr/bin/env python3
"""Analyze one or more reference videos into timestamped, reusable evidence.

Semantic shot labels are intentionally left for vision review or human annotation. The
computer-vision pass measures boundaries, framing, color, motion, and audio evidence.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import subprocess
from pathlib import Path

import cv2
import numpy as np
from scipy import signal
from scipy.io import wavfile

ROOT = Path(__file__).resolve().parents[1]
FFPROBE = ROOT / "node_modules/@remotion/compositor-linux-x64-gnu/ffprobe"
FFMPEG = ROOT / "node_modules/@remotion/compositor-linux-x64-gnu/ffmpeg"


def slug(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value[:60] or "reference"


def probe(path: Path) -> dict:
    return json.loads(subprocess.check_output([str(FFPROBE), "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)], text=True))


def extract_audio(video: Path, output: Path) -> None:
    subprocess.run([str(FFMPEG), "-y", "-v", "error", "-i", str(video), "-vn", "-ac", "2", "-ar", "48000", "-c:a", "pcm_s16le", str(output)], check=True)


def color_summary(frame: np.ndarray) -> dict:
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mean = frame.reshape(-1, 3).mean(axis=0)
    return {
        "meanBgr": [round(float(value), 2) for value in mean],
        "meanSaturation": round(float(hsv[:, :, 1].mean()), 2),
        "meanValue": round(float(hsv[:, :, 2].mean()), 2),
        "warmPixelRatio": round(float(((frame[:, :, 2] > frame[:, :, 0] * 1.18) & (frame[:, :, 2] > frame[:, :, 1] * 1.03)).mean()), 4),
    }


def detect_scenes(video: Path, fps: float, frame_count: int) -> tuple[list[dict], list[tuple[float, np.ndarray]]]:
    capture = cv2.VideoCapture(str(video))
    previous = None
    boundaries = [0]
    scores: list[dict] = []
    representatives: list[tuple[float, np.ndarray]] = []
    frame_index = 0
    minimum_gap_frames = max(1, int(fps * 0.8))
    while True:
        ok, frame = capture.read()
        if not ok:
            break
        small = cv2.resize(frame, (160, 284), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        score = 0.0 if previous is None else float(np.mean(cv2.absdiff(gray, previous)))
        if previous is not None and score > 18 and frame_index - boundaries[-1] >= minimum_gap_frames:
            boundaries.append(frame_index)
        if frame_index % max(1, int(fps * 2)) == 0:
            scores.append({"timestampSeconds": round(frame_index / fps, 3), "frameDifference": round(score, 3)})
        previous = gray
        frame_index += 1
    capture.release()
    if frame_index and boundaries[-1] >= frame_index - minimum_gap_frames:
        boundaries.pop()
    boundary_data = []
    for index, start in enumerate(boundaries):
        end = boundaries[index + 1] if index + 1 < len(boundaries) else frame_index
        boundary_data.append({"sceneIndex": index, "startSeconds": round(start / fps, 3), "endSeconds": round(end / fps, 3), "durationSeconds": round((end - start) / fps, 3), "boundaryEvidence": scores[min(len(scores) - 1, int(start / max(1, fps * 2)))] if scores else {}})
    # Extract one frame at each detected scene start and at regular intervals.
    capture = cv2.VideoCapture(str(video))
    wanted = sorted(set(boundaries + [int(frame_count * index / 12) for index in range(12)]))
    wanted_set = set(wanted)
    for index in range(frame_count):
        if index not in wanted_set:
            capture.grab()
            continue
        ok, frame = capture.read()
        if ok:
            representatives.append((index / fps, frame.copy()))
    capture.release()
    return boundary_data, representatives


def write_contact_sheet(frames: list[tuple[float, np.ndarray]], output: Path) -> None:
    if not frames:
        return
    width, height = 240, 426
    columns = 4
    rows = math.ceil(len(frames) / columns)
    canvas = np.full((rows * (height + 28), columns * width, 3), 18, dtype=np.uint8)
    for index, (timestamp, frame) in enumerate(frames):
        thumb = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
        x, y = (index % columns) * width, (index // columns) * (height + 28)
        canvas[y:y + height, x:x + width] = thumb
        cv2.putText(canvas, f"{timestamp:.2f}s", (x + 8, y + height + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (235, 235, 235), 1, cv2.LINE_AA)
    cv2.imwrite(str(output), canvas, [cv2.IMWRITE_JPEG_QUALITY, 92])


def analyze_audio(wav_path: Path, duration: float) -> dict:
    sample_rate, raw = wavfile.read(wav_path)
    data = raw.astype(np.float64)
    if np.issubdtype(raw.dtype, np.integer):
        data /= np.iinfo(raw.dtype).max
    mono = data.mean(axis=1) if data.ndim == 2 else data
    window = max(1, int(sample_rate * 0.25))
    rms = []
    centroid = []
    times = []
    for start in range(0, len(mono), window):
        chunk = mono[start:start + window]
        if not len(chunk):
            continue
        spectrum = np.abs(np.fft.rfft(chunk * np.hanning(len(chunk))))
        frequencies = np.fft.rfftfreq(len(chunk), 1 / sample_rate)
        rms.append(float(np.sqrt(np.mean(chunk ** 2) + 1e-12)))
        centroid.append(float((frequencies * spectrum).sum() / max(spectrum.sum(), 1e-9)))
        times.append(start / sample_rate)
    rms_array = np.asarray(rms)
    db = 20 * np.log10(np.maximum(rms_array, 1e-9))
    changes = np.abs(np.diff(signal.savgol_filter(db, min(11, len(db) // 2 * 2 + 1) if len(db) > 4 else 3, 2 if len(db) > 4 else 1))) if len(db) > 4 else np.array([])
    peaks, properties = signal.find_peaks(changes, height=2.0, distance=max(1, int(1.0 / 0.25))) if len(changes) else ([], {})
    events = [{"timestampSeconds": round(times[index + 1], 3), "type": "energy-change", "confidence": round(float(min(0.99, properties['peak_heights'][offset] / 10)), 2), "evidence": "RMS change; effect identity not inferred"} for offset, index in enumerate(peaks)]
    return {
        "path": str(wav_path.relative_to(ROOT)),
        "sampleRateHz": int(sample_rate),
        "channels": int(data.shape[1]) if data.ndim == 2 else 1,
        "durationSeconds": round(len(mono) / sample_rate, 3),
        "rmsDb": {"min": round(float(db.min()), 2), "max": round(float(db.max()), 2), "mean": round(float(db.mean()), 2)},
        "spectralCentroidHz": {"min": round(float(min(centroid)), 2), "max": round(float(max(centroid)), 2), "mean": round(float(np.mean(centroid)), 2)},
        "events": events,
        "semanticConfidence": "low: signal analysis cannot identify narration, music, or specific SFX without a model review",
    }


def analyze_video(path: Path, output_root: Path) -> dict:
    metadata = probe(path)
    video_stream = next(stream for stream in metadata.get("streams", []) if stream.get("codec_type") == "video")
    audio_stream = next((stream for stream in metadata.get("streams", []) if stream.get("codec_type") == "audio"), None)
    fps = float(video_stream.get("r_frame_rate", "30/1").split("/")[0]) / float(video_stream.get("r_frame_rate", "30/1").split("/")[1])
    duration = float(metadata.get("format", {}).get("duration", video_stream.get("duration", 0)))
    frame_count = int(video_stream.get("nb_frames") or round(duration * fps))
    output = output_root / slug(path.stem)
    (output / "frames").mkdir(parents=True, exist_ok=True)
    audio_path = output / "audio.wav"
    extract_audio(path, audio_path)
    scenes, representatives = detect_scenes(path, fps, frame_count)
    for index, (timestamp, frame) in enumerate(representatives):
        cv2.imwrite(str(output / "frames" / f"frame-{index:03d}-{timestamp:.3f}s.jpg"), frame, [cv2.IMWRITE_JPEG_QUALITY, 92])
    write_contact_sheet(representatives, output / "contact-sheet.jpg")
    result = {
        "referenceId": slug(path.stem),
        "sourcePath": str(path.relative_to(ROOT)),
        "sourcePreserved": path.exists(),
        "metadata": {"durationSeconds": round(duration, 3), "width": int(video_stream["width"]), "height": int(video_stream["height"]), "fps": round(fps, 3), "frameCount": frame_count, "videoCodec": video_stream.get("codec_name"), "audioCodec": audio_stream.get("codec_name") if audio_stream else None, "audioSampleRateHz": int(audio_stream.get("sample_rate", 0)) if audio_stream else None, "audioChannels": int(audio_stream.get("channels", 0)) if audio_stream else None},
        "sceneBoundaries": scenes,
        "representativeFrames": [{"timestampSeconds": round(timestamp, 3), "path": f"frames/frame-{index:03d}-{timestamp:.3f}s.jpg", "semanticStatus": "requires vision or human annotation"} for index, (timestamp, _) in enumerate(representatives)],
        "audioAnalysis": analyze_audio(audio_path, duration),
        "semanticAnalysis": {"status": "measurement plus human-review scaffold", "limitation": "OpenCV and FFmpeg measured changes, color, framing, and audio signal only; shot meaning, camera intent, typography, and SFX identity require vision or human review."},
        "artifacts": {"metadata": "metadata.json", "sceneBoundaries": "scene-boundaries.json", "audio": "audio-analysis.json", "contactSheet": "contact-sheet.jpg"},
    }
    (output / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / "metadata.json").write_text(json.dumps(result["metadata"], indent=2) + "\n")
    (output / "scene-boundaries.json").write_text(json.dumps(result["sceneBoundaries"], indent=2) + "\n")
    (output / "audio-analysis.json").write_text(json.dumps(result["audioAnalysis"], indent=2) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("videos", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "reference/analysis")
    args = parser.parse_args()
    results = [analyze_video((ROOT / video).resolve() if not video.is_absolute() else video, args.output.resolve()) for video in args.videos]
    (args.output / "index.json").write_text(json.dumps({"references": [{"referenceId": result["referenceId"], "sourcePath": result["sourcePath"], "analysisPath": f"{result['referenceId']}/analysis.json"} for result in results]}, indent=2) + "\n")
    print(json.dumps({"analyzed": len(results), "references": [result["referenceId"] for result in results]}, indent=2))


if __name__ == "__main__":
    main()
