import {mkdir, readFile, stat, writeFile} from 'node:fs/promises';
import {dirname, resolve} from 'node:path';
import {parseProject} from '../src/types/project';
import {estimateTiming, parseTiming} from '../src/core/timing';
import {validateProjectSemantics} from '../src/core/validation';

const projectPath = resolve(process.argv[2] ?? 'projects/sample/project.json');
const outputPath = resolve(process.argv[3] ?? `${dirname(projectPath)}/data/timing.json`);
const project = parseProject(JSON.parse(await readFile(projectPath, 'utf8')));
const hasExistingTiming = await exists(outputPath);
const timing = hasExistingTiming ? parseTiming(JSON.parse(await readFile(outputPath, 'utf8'))) : estimateTiming(project);
const issues = validateProjectSemantics(project, timing);
if (issues.length) throw new Error(issues.map((issue) => `${issue.path}: ${issue.message}`).join('\n'));
if (!hasExistingTiming) {
  await mkdir(dirname(outputPath), {recursive: true});
  await writeFile(outputPath, `${JSON.stringify(timing, null, 2)}\n`);
  console.log(`WROTE: ${outputPath}`);
} else {
  console.log(`KEPT: ${outputPath}`);
}
console.log(`${timing.estimated ? 'Estimated' : 'Aligned'} duration: ${timing.durationSeconds.toFixed(2)}s`);

async function exists(filePath: string): Promise<boolean> {
  try {
    await stat(filePath);
    return true;
  } catch {
    return false;
  }
}
