import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import type {CaptionChunk} from '../core/captions';
import {secondsToFrames} from '../core/timing';

export function CaptionOverlay({chunks, offsetSeconds = 0, theme = 'default'}: {chunks: CaptionChunk[]; offsetSeconds?: number; theme?: 'default' | 'voice-studio' | 'reference'}) {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const active = chunks.find((chunk) => {
    const start = secondsToFrames(chunk.startSeconds - offsetSeconds, fps);
    const end = secondsToFrames(chunk.endSeconds - offsetSeconds, fps);
    return frame >= start && frame <= end;
  });

  if (!active) return null;
  const start = secondsToFrames(active.startSeconds - offsetSeconds, fps);
  const entrance = interpolate(frame - start, [0, 8], [0.78, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const words = active.text.split(' ');
  const reference = theme === 'reference';

  return (
    <AbsoluteFill style={{justifyContent: reference ? 'flex-start' : 'flex-end', alignItems: 'center', paddingTop: reference ? 86 : 0, paddingBottom: reference ? 0 : 290, pointerEvents: 'none'}}>
      <div style={{transform: `scale(${entrance})`, display: 'flex', gap: reference ? 8 : theme === 'voice-studio' ? 12 : 16, maxWidth: 900, flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center'}}>
        {words.map((word) => {
          const highlighted = active.highlight?.toLowerCase() === word.toLowerCase();
          return <span key={word} style={{fontFamily: reference || theme === 'voice-studio' ? 'Arial, sans-serif' : 'Arial, sans-serif', fontSize: reference ? 42 : theme === 'voice-studio' ? 62 : 58, fontWeight: 900, color: reference ? '#FFFDF8' : theme === 'voice-studio' ? '#F1C66D' : highlighted ? '#3B62DB' : '#141414', background: reference && highlighted ? '#3B62DB' : 'transparent', padding: reference && highlighted ? '3px 8px' : 0, borderRadius: reference && highlighted ? 5 : 0, textShadow: reference ? '0 3px 10px #26152B' : theme === 'voice-studio' ? '0 4px 8px #111018' : '0 3px 0 #ffffff, 3px 0 0 #ffffff, -3px 0 0 #ffffff'}}>{word}</span>;
        })}
      </div>
    </AbsoluteFill>
  );
}
