#!/usr/bin/env python3
"""Create a directed narration, music, and event-driven SFX mix."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48_000


def read_mono(path: Path) -> np.ndarray:
    source_rate, raw = wavfile.read(path)
    data = np.asarray(raw, dtype=np.float64)
    if data.ndim == 2:
        data = data.mean(axis=1)
    if np.issubdtype(raw.dtype, np.integer):
        data = data / np.iinfo(raw.dtype).max
    if source_rate != SR:
        data = signal.resample_poly(data, SR, source_rate)
    return data.astype(np.float64)


def envelope(length: int, attack: float, release: float) -> np.ndarray:
    result = np.ones(length)
    attack_count = max(1, min(length, int(attack * SR)))
    release_count = max(1, min(length, int(release * SR)))
    result[:attack_count] = np.linspace(0, 1, attack_count)
    result[-release_count:] *= np.linspace(1, 0, release_count)
    return result


def tone(frequency: float, duration: float, decay: float = 6.0) -> np.ndarray:
    count = max(1, int(duration * SR))
    t = np.arange(count) / SR
    return np.sin(2 * np.pi * frequency * t) * np.exp(-t * decay)


def whoosh(duration: float = 0.35) -> np.ndarray:
    count = max(1, int(duration * SR))
    noise = np.random.default_rng(17).normal(0, 1, count)
    frequencies = np.linspace(220, 1500, count)
    sweep = np.sin(2 * np.pi * np.cumsum(frequencies) / SR)
    return (noise * 0.08 + sweep * 0.14) * envelope(count, 0.01, duration * 0.8)


def swirl(duration: float = 0.62) -> np.ndarray:
    count = max(1, int(duration * SR))
    t = np.arange(count) / SR
    frequency = 180 + 1000 * (t / duration) ** 2
    carrier = np.sin(2 * np.pi * np.cumsum(frequency) / SR)
    shimmer = np.sin(2 * np.pi * (frequency * 1.51) * t)
    return (carrier * 0.12 + shimmer * 0.05) * envelope(count, 0.03, duration * 0.65)


def pop(duration: float = 0.13) -> np.ndarray:
    first = tone(540, duration, 28) * 0.45
    second = tone(820, duration * 0.55, 35) * 0.16
    offset = int(0.025 * SR)
    result = np.zeros(max(len(first), offset + len(second)))
    result[:len(first)] += first
    result[offset:offset + len(second)] += second
    return result


def click(duration: float = 0.045) -> np.ndarray:
    count = max(1, int(duration * SR))
    noise = np.random.default_rng(4).normal(0, 1, count)
    return signal.lfilter([0.4], [1, -0.6], noise) * envelope(count, 0.001, duration * 0.75) * 0.15


def tick(duration: float = 0.07) -> np.ndarray:
    return tone(1250, duration, 32) * 0.2


def impact(duration: float = 0.32) -> np.ndarray:
    count = max(1, int(duration * SR))
    t = np.arange(count) / SR
    low = np.sin(2 * np.pi * (70 - 35 * t / duration) * t) * np.exp(-t * 9)
    return low * 0.3


def riser(duration: float = 0.8) -> np.ndarray:
    count = max(1, int(duration * SR))
    t = np.arange(count) / SR
    frequency = 140 * (1600 / 140) ** (t / duration)
    return np.sin(2 * np.pi * np.cumsum(frequency) / SR) * envelope(count, 0.3, 0.15) * 0.15


def success(duration: float = 0.36) -> np.ndarray:
    first = tone(660, min(0.18, duration), 8)
    second = tone(990, min(0.28, duration), 7)
    result = np.zeros(max(len(first), int(0.08 * SR) + len(second)))
    result[:len(first)] += first
    result[int(0.08 * SR):int(0.08 * SR) + len(second)] += second
    return result * envelope(len(result), 0.005, min(0.12, duration * 0.4))


def sparkle(duration: float = 0.55) -> np.ndarray:
    result = np.zeros(max(1, int(duration * SR)))
    for index, frequency in enumerate((880, 1175, 1568)):
        sound = tone(frequency, min(0.28, duration), 8) * 0.12
        start = int(index * 0.1 * SR)
        if start < len(result):
            result[start:start + len(sound)] += sound[:len(result) - start]
    return result


EFFECTS = {name: effect for name, effect in {
    'whoosh': whoosh, 'swirl': swirl, 'pop': pop, 'click': click, 'tick': tick,
    'impact': impact, 'riser': riser, 'success': success, 'sparkle': sparkle,
}.items()}


def music(duration: float, settings: dict, sections: list[dict]) -> tuple[np.ndarray, dict]:
    count = max(1, int(duration * SR))
    t = np.arange(count) / SR
    mood = settings.get('music', {}).get('mood', 'warm-tech')
    chords = {
        'warm-tech': [(110.0, 164.8, 220.0), (98.0, 146.8, 196.0), (123.5, 185.0, 246.9), (110.0, 164.8, 220.0)],
        'cinematic': [(82.4, 123.5, 164.8), (73.4, 110.0, 146.8), (98.0, 146.8, 196.0), (82.4, 123.5, 164.8)],
        'calm': [(98.0, 146.8, 196.0), (110.0, 164.8, 220.0), (82.4, 123.5, 164.8), (98.0, 146.8, 196.0)],
        'urgent': [(146.8, 220.0, 293.7), (130.8, 196.0, 261.6), (164.8, 246.9, 329.6), (146.8, 220.0, 293.7)],
    }.get(mood, [(110.0, 164.8, 220.0)] * 4)
    result = np.zeros(count)
    bar = 2.4
    for index, start in enumerate(np.arange(0, duration + bar, bar)):
        begin = int(start * SR)
        end = min(count, begin + int(bar * SR))
        if begin >= count:
            break
        local = t[begin:end] - start
        result[begin:end] += sum(np.sin(2 * np.pi * frequency * local) for frequency in chords[index % len(chords)]) / 3 * 0.055
    automation = np.ones(count)
    section_report = []
    for section in sections:
        start = max(0, int(section['startSeconds'] * SR))
        end = min(count, int(section['endSeconds'] * SR))
        if end <= start:
            continue
        automation[start:end] = float(section['intensity'])
        section_report.append({**section, 'startSeconds': round(section['startSeconds'], 3), 'endSeconds': round(section['endSeconds'], 3)})
    intro = float(settings.get('music', {}).get('introSeconds', 0.8))
    outro = float(settings.get('music', {}).get('outroSeconds', 1.2))
    automation *= envelope(count, intro, outro)
    result *= automation
    return result, {'mood': mood, 'sections': section_report, 'minIntensity': round(float(np.min(automation)), 3), 'maxIntensity': round(float(np.max(automation)), 3), 'introSeconds': intro, 'outroSeconds': outro}


def normalize_word(value: str) -> str:
    return ''.join(character for character in value.lower() if character.isalnum())


def resolve_audio_events(settings: dict, timing: dict) -> tuple[list[dict], list[dict]]:
    lines = {line['lineId']: line for line in timing.get('lines', [])}
    words = timing.get('words', [])
    events: list[dict] = []
    warnings: list[dict] = []
    for scene in settings.get('scenes', []):
        line = lines.get(scene.get('lineId'))
        if not line:
            continue
        line_words = [word for word in words if word.get('lineId') == scene.get('lineId')]
        for shot in scene.get('shotTimeline', []):
            for event in shot.get('audioEvents', []):
                matching = next((word for word in line_words if normalize_word(word['text']) == normalize_word(event.get('atWord', ''))), None) if event.get('atWord') else None
                if matching:
                    timestamp = float(matching['startSeconds'])
                    resolution = 'aligned-word'
                elif event.get('timestampSeconds') is not None:
                    timestamp = float(line['startSeconds']) + float(shot['startSeconds']) + float(event['timestampSeconds'])
                    resolution = 'shot-relative-timestamp'
                else:
                    timestamp = float(line['startSeconds']) + float(shot['startSeconds'])
                    resolution = 'shot-start-fallback'
                    warnings.append({'sceneId': scene['id'], 'shotId': shot['id'], 'event': event['type'], 'reason': 'atWord was not found; placed at shot start'})
                events.append({
                    'timestampSeconds': round(timestamp, 3),
                    'durationSeconds': float(event.get('durationSeconds', 0.35)),
                    'type': event['type'],
                    'category': event.get('category', 'texture'),
                    'sourceAsset': event['sourceAsset'],
                    'volume': float(event.get('volume', 0.5)),
                    'fadeInSeconds': float(event.get('fadeInSeconds', 0.01)),
                    'fadeOutSeconds': float(event.get('fadeOutSeconds', 0.08)),
                    'reason': event['reason'],
                    'sceneId': scene['id'],
                    'shotId': shot['id'],
                    'resolution': resolution,
                })
        if not scene.get('shotTimeline'):
            for cue in scene.get('audioCues', []):
                matching = next((word for word in [word for word in words if word.get('lineId') == scene.get('lineId')] if normalize_word(word['text']) == normalize_word(cue.get('atWord', ''))), None)
                events.append({'timestampSeconds': round(float(matching['startSeconds']) if matching else float(line['startSeconds']), 3), 'durationSeconds': 0.35, 'type': cue['type'], 'category': 'texture', 'sourceAsset': f"assets/library/audio/sfx/{cue['type']}.wav", 'volume': 0.3, 'fadeInSeconds': 0.01, 'fadeOutSeconds': 0.08, 'reason': 'Explicit scene audio cue', 'sceneId': scene['id'], 'shotId': scene['id'], 'resolution': 'aligned-word' if matching else 'line-start-fallback'})
    return sorted(events, key=lambda event: event['timestampSeconds']), warnings


def main() -> None:
    project_path = Path(sys.argv[1] if len(sys.argv) > 1 else 'projects/sample/project.json')
    data_dir = project_path.parent / 'data'
    timing = json.loads((data_dir / 'timing.json').read_text())
    settings = json.loads(project_path.read_text())
    duration = float(timing['durationSeconds'])
    narration = read_mono(data_dir / 'narration.wav') if (data_dir / 'narration.wav').exists() else np.zeros(int(duration * SR))
    count = max(len(narration), int((duration + 0.1) * SR))
    narration = np.pad(narration, (0, max(0, count - len(narration))))[:count]
    mix = np.zeros((count, 2), dtype=np.float64)
    voice_rms = np.sqrt(np.mean(narration ** 2) + 1e-12)
    has_voice = voice_rms > 0.00001
    if has_voice:
        narration = narration * (10 ** (-18 / 20)) / voice_rms
    mix += narration[:, None]

    events, warnings = resolve_audio_events(settings, timing)
    sections = []
    for scene in settings.get('scenes', []):
        line = next((line for line in timing.get('lines', []) if line['lineId'] == scene['lineId']), None)
        if not line:
            continue
        for shot in scene.get('shotTimeline', []):
            music_settings = shot.get('music', {'intensity': 0.6, 'duckingDb': 8})
            sections.append({'sceneId': scene['id'], 'shotId': shot['id'], 'startSeconds': float(line['startSeconds']) + float(shot['startSeconds']), 'endSeconds': float(line['startSeconds']) + float(shot['endSeconds']), 'intensity': float(music_settings['intensity']), 'duckingDb': float(music_settings['duckingDb'])})

    automation = {'mode': settings.get('music', {}).get('mode', 'none'), 'sections': [], 'ducking': {'targetDb': float(settings.get('music', {}).get('duckingDb', 8)), 'minGainDb': 0.0, 'maxGainDb': 0.0}}
    if settings.get('music', {}).get('mode') != 'none':
        bed, automation = music(duration + 0.1, settings, sections)
        absolute_voice = np.abs(narration)
        speech = signal.lfilter([0.015], [1, -0.985], absolute_voice)
        threshold = max(float(np.percentile(speech, 75)), 1e-6)
        speech_amount = np.clip(speech / threshold, 0, 1)
        target_db = np.full(count, float(settings.get('music', {}).get('duckingDb', 8)))
        for section in sections:
            start = max(0, int(section['startSeconds'] * SR))
            end = min(count, int(section['endSeconds'] * SR))
            target_db[start:end] = float(section['duckingDb'])
        duck_gain = 10 ** (-(speech_amount * target_db) / 20)
        bed *= duck_gain
        automation['ducking'] = {'targetDb': round(float(np.max(target_db)), 2), 'minTargetDb': round(float(np.min(target_db)), 2), 'minGainDb': round(float(20 * np.log10(max(float(np.min(duck_gain)), 1e-9))), 2), 'maxGainDb': round(float(20 * np.log10(max(float(np.max(duck_gain)), 1e-9))), 2)}
        mix += bed[:, None]

    for event in events:
        effect_fn = EFFECTS.get(event['type'])
        if not effect_fn:
            warnings.append({'event': event['type'], 'reason': 'No matching curated effect in library'})
            continue
        asset_path = Path(event['sourceAsset'])
        if not asset_path.is_absolute():
            asset_path = Path.cwd() / asset_path
        if asset_path.exists():
            effect = read_mono(asset_path)
            wanted = max(1, int(float(event['durationSeconds']) * SR))
            if len(effect) >= wanted:
                effect = effect[:wanted]
            else:
                effect = np.pad(effect, (0, wanted - len(effect)))
            event['renderedSource'] = 'asset-file'
        else:
            effect = effect_fn(float(event['durationSeconds']))
            event['renderedSource'] = 'procedural-fallback'
        fade_in = max(1, int(float(event['fadeInSeconds']) * SR))
        fade_out = max(1, int(float(event['fadeOutSeconds']) * SR))
        fade_in_count = min(fade_in, len(effect))
        fade_out_count = min(fade_out, len(effect))
        effect[:fade_in_count] *= np.linspace(0, 1, fade_in_count)
        effect[-fade_out_count:] *= np.linspace(1, 0, fade_out_count)
        start = int(event['timestampSeconds'] * SR)
        end = min(count, start + len(effect))
        if 0 <= start < count:
            gain = float(event['volume'])
            mix[start:end, 0] += effect[:end - start] * gain * 0.8
            mix[start:end, 1] += effect[:end - start] * gain

    peak = max(float(np.max(np.abs(mix))), 1e-9)
    mix = mix / peak * (10 ** (-1.0 / 20))
    data_dir.mkdir(exist_ok=True)
    wavfile.write(data_dir / 'mix.wav', SR, np.clip(mix, -1, 1).astype(np.float32))
    (data_dir / 'audio-events.json').write_text(json.dumps({'durationSeconds': duration, 'events': events, 'warnings': warnings}, indent=2) + '\n')
    out_dir = Path('out')
    out_dir.mkdir(exist_ok=True)
    report = {'projectId': settings['id'], 'status': 'pass' if not warnings else 'pass-with-warnings', 'durationSeconds': duration, 'narration': {'present': bool(has_voice), 'rmsDb': round(float(20 * np.log10(max(voice_rms, 1e-9))), 2)}, 'events': {'count': len(events), 'byType': {event_type: sum(event['type'] == event_type for event in events) for event_type in sorted({event['type'] for event in events})}, 'warnings': warnings}, 'musicAutomation': automation, 'mix': {'sampleRateHz': SR, 'channels': 2, 'peakDb': round(float(20 * np.log10(max(peak, 1e-9))), 2)}}
    (out_dir / 'audio-report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'WROTE: {data_dir / "mix.wav"} ({duration:.2f}s, narration={has_voice}, events={len(events)}, music={settings.get("music", {}).get("mode")})')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
