# Reference fidelity root-cause report

**Reference:** SnapInsta MP4 from `main`  
**Baseline:** `out/style-test-final.mp4` before the correction loop  
**Corrected test:** `out/style-test-final.mp4` after the organic character, caption, object, and gap fixes

## What the analysis extracted

The ingestion pass in `scripts/analyze-reference.py` produced FFprobe metadata, extracted WAV audio, OpenCV candidate boundaries, representative frames, contact sheet, RMS/spectral measurements, and confidence-labeled audio events. The SnapInsta evidence is:

- `reference/analysis/snapinsta-to-aqmmlqfuq0m4g6b2clb9enjihkwaf2sfwvlvozru-klywzb/analysis.json`
- `scene-boundaries.json`
- `contact-sheet.jpg`
- `audio-analysis.json`

The reference is 68.628 seconds, 720×1280, 30 FPS, with 33 detected candidate scene starts. Its measured median candidate shot duration is 1.967 seconds. The contact sheet visibly shows a recurring warm studio, expressive presenter, companion character, short portrait close-ups, floating rounded UI cards, and character-to-card alternation.

## Translation failure

| Reference evidence | Blueprint field | Storyboard/renderer state before correction | Failure |
|---|---|---|---|
| Warm sunset studio with window depth and string lights | `visualIdentity.environment`, `visualIdentity.lighting` | Blueprint existed, but renderer only changed wall/background colors | Architecture and atmosphere were mostly absent |
| Rounded expressive presenter and companion | `shotLibrary`, `animationLanguage` | `projects/style-test/project.json` attached `RobotExpressive.glb` to every scene | The renderer always selected the low-poly robot because `characterModelPath` took priority |
| Organic object/product demonstrations | `shotLibrary.object-proof` | `ObjectCloseGeometry` always rendered microphone, laptop, and orb | Topic-specific objects were lost |
| Floating UI cards | `shotLibrary.floating-ui-demo`, `typography.ui` | UI branch was reused, but only as a fixed generic card | UI was not selected from reference examples or topic object identity |
| Short varied beats | `pacing.shortShotRangeSeconds` | Timelines used manually guessed durations | Last shot of each scene ended before its parent scene range |
| Character-led opening | `shotLibrary.studio-wide` | First shot was an abstract diagram with a large orb | The hook lost the reference's human anchor |
| Specific camera/focus changes | `cameraLanguage` | Camera target support existed, but most plans reused abstract targets | The target was not tied to the subject/object identity |
| Audio pacing and effects | `soundDesign` | Audio events existed, but the original plan did not record reference-to-event evidence | Sound could be rendered without a visible event relationship |

## Why the robot and orb appeared

The renderer had this effective priority:

1. If `scene.assets.characterModelPath` exists, render `GltfCharacter`.
2. Otherwise render the primitive `Presenter`.
3. Most diagrams, data visualizations, and split screens render `VoiceOrb`.

The style-test project supplied `assets/models/RobotExpressive.glb` for every scene. The reference style ID was present, but no code used that ID to override character selection. Therefore the blueprint was metadata, not an executable character/environment policy.

The large orange orb came from the shared geometry branches. `DiagramGeometry`, `DataVizGeometry`, and `SplitScreenGeometry` all used `VoiceOrb` regardless of narration subject. No `objectKind` or reference example lookup existed.

## Why compositions repeated

All shot types shared most of the same studio primitives: wall, floor, desk, laptop, microphone, orb, and character. The timeline changed camera coordinates and labels, but not enough of the subject hierarchy. This produced different labels over the same visual grammar instead of reference-like progression.

The correction adds:

- Reference-aware background treatment with a window, sunset blocks, and string lights.
- Deliberate rounded presenter and companion characters for the selected reference style.
- `objectKind` and `objectLabel` in the shot contract.
- A topic-specific headphone object for headphone shots.
- A character-led opening.
- Reference caption treatment with phrase captions and highlighted keywords.
- Smaller non-character signal dots/companions instead of a giant orb in reference process shots.

## Black-frame gaps

The baseline project used approximate shot timeline ends. The parent Remotion scene range is based on narration timing, but the final nested shot ended earlier. For example, the final shot ended at its manually authored duration while the parent scene continued through the line's timing plus gap. `ShotLayer` rendered nothing during the remainder, exposing the root background. The same mismatch occurred between several intermediate line starts and the last nested shot of the preceding scene.

The renderer now extends the last nested shot to the parent scene end when the authored timeline is shorter. This preserves the authored camera/overlay behavior while preventing uncovered frames. The corrected render's creative QA has no blank samples.

## Remaining limitations

- The reference characters are not copied. The corrected output uses an original rounded presenter and companion built for this style, not the reference models.
- The output still uses procedural Three.js assets rather than a licensed bespoke GLTF character rig. The asset manifest records that choice.
- The reference audio analysis identifies energy changes, not exact SFX identities. The generated audio uses explicit local assets with reasons rather than pretending the reference waveform proves a particular sound.
- No embedding-based visual similarity score is claimed. `out/reference-style-qa-report.json` reports concrete composition, pacing, camera, overlay, audio, and character comparisons with evidence.
