# Script brief

Topic: How local voice generation works
Duration target: 30s
Style: voice-studio-3d

The existing sample project remains the approved render input until a script provider is configured.
