# Research brief

Topic: How local voice generation works

Local MVP mode: claims require human review before publication.
