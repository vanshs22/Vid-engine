from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase

from backend.app.models import ProjectRequest
from backend.app.orchestrator import Director
from backend.app.registry import AgentRegistry


class AgentFoundationSmokeTest(TestCase):
    def test_registry_has_mvp_agents(self):
        names = {agent.name for agent in AgentRegistry().list()}
        self.assertIn("director", names)
        self.assertIn("quality", names)
        self.assertGreaterEqual(len(names), 10)

    def test_director_creates_checkpoint(self):
        with TemporaryDirectory() as directory:
            state = Director(Path(directory)).create_state(ProjectRequest(project_id="smoke"))
            self.assertEqual(state.stage, "planned")
            self.assertTrue((Path(directory) / ".cache/agent-state.sqlite3").exists())
    def test_reference_library_loads_blueprint_and_feedback(self):
        from backend.app.reference_library import ReferenceLibrary
        from backend.app.models import ReferenceFeedback

        root = Path(__file__).resolve().parents[2]
        library = ReferenceLibrary(root)
        references = library.list()
        self.assertTrue(any(item['id'] == 'snapinsta-cinematic-3d' for item in references))
        detail = library.get('snapinsta-cinematic-3d')
        self.assertIsNotNone(detail)
        self.assertEqual(detail['blueprint']['cameraLanguage']['defaultFraming'], 'medium vertical portrait and close-up alternation')
        with TemporaryDirectory() as directory:
            local = ReferenceLibrary(Path(directory))
            local.blueprint_dir = root / 'src/styles/referenceBlueprints'
            local.feedback_path = Path(directory) / 'feedback.json'
            saved = local.add_feedback('snapinsta-cinematic-3d', ReferenceFeedback(kind='camera-speed', value='slower', note='Hold the character reveal longer'))
            self.assertEqual(saved['kind'], 'camera-speed')

if __name__ == "__main__":
    import unittest
    unittest.main()
