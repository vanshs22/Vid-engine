import {Composition, Sequence, AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {ReactNode} from 'react';
import sampleProject from '../projects/sample/project.json';
import {CaptionOverlay} from './components/CaptionOverlay';
import {captionsForLine} from './core/captions';
import {estimateTiming, secondsToFrames, timingForScene} from './core/timing';
import {normalizeRenderProps, type RenderProps} from './core/renderProps';
import {parseProject, type ShotTimelineSegment} from './types/project';
import {directSceneWithStyle} from './engines/story/director';
import {InsideOutScene} from './styles/insideOut';
import {ThreeProofScene} from './styles/threeProof';
import {StickStoryScene} from './styles/stickStory';
import {VoiceStudioScene} from './styles/voiceStudio';
import {VoiceStudio3DScene} from './styles/voiceStudio3D';
import {MotionGraphicsScene} from './styles/motionGraphics';
import {SceneTransition} from './transitions/sceneTransition';

const project = parseProject(sampleProject);
const timing = estimateTiming(project);
const fallbackRenderProps: RenderProps = {project, timing};

export const VIDEO_ID = 'UniversalVideoStudio';

export function Root() {
  return (
    <>
      <Composition
        id={VIDEO_ID}
        component={VideoComposition}
        durationInFrames={secondsToFrames(timing.durationSeconds, project.format.fps)}
        fps={project.format.fps}
        width={project.format.width}
        height={project.format.height}
        defaultProps={{project, timing}}
        calculateMetadata={({props}) => {
          const input = normalizeRenderProps(props, fallbackRenderProps);
          return {
            durationInFrames: secondsToFrames(input.timing.durationSeconds, input.project.format.fps),
            fps: input.project.format.fps,
            width: input.project.format.width,
            height: input.project.format.height,
          };
        }}
      />
    </>
  );
}

function VideoComposition(inputProps: unknown) {
  const {project, timing, narrationPath, musicPath, mixPath} = normalizeRenderProps(inputProps, fallbackRenderProps);
  const {fps} = useVideoConfig();

  return (
    <AbsoluteFill style={{backgroundColor: '#111319'}}>
      {project.scenes.map((scene, sceneIndex) => {
        const range = timingForScene(timing, scene.lineId, fps);
        const sceneRange = sceneIndex === 0 && range.from > 0 ? {from: 0, durationInFrames: range.durationInFrames + range.from} : range;
        const line = project.lines.find((candidate) => candidate.id === scene.lineId);
        if (!line) return null;
        const captionChunks = captionsForLine(line, timing, project.captionStyle);
        const lineTiming = timing.lines.find((candidate) => candidate.lineId === line.id);
        const directedScene = scene.visualPlan ? {...scene, visualPlan: {...scene.visualPlan, referenceStyle: scene.visualPlan.referenceStyle ?? project.referenceStyle, renderer: scene.visualPlan.renderer ?? (scene.visualStyle === 'claude-animation' ? 'stick-story' : scene.visualStyle)}} : {...scene, visualPlan: directSceneWithStyle(line, scene, project.referenceStyle)};
        const timeline = directedScene.shotTimeline ?? [];
        return (
          <Sequence key={scene.id} from={sceneRange.from} durationInFrames={sceneRange.durationInFrames} name={scene.id}>
            <SceneLayer scene={directedScene} durationInFrames={sceneRange.durationInFrames} hasShotTimeline={timeline.length > 0}>
              {timeline.length > 0 ? timeline.map((shot, shotIndex) => {
                const isLastShot = shotIndex === timeline.length - 1;
                const plannedEndSeconds = isLastShot ? Math.max(shot.endSeconds, sceneRange.durationInFrames / fps) : shot.endSeconds;
                const renderedShot = plannedEndSeconds === shot.endSeconds ? shot : {...shot, endSeconds: plannedEndSeconds};
                const from = secondsToFrames(shot.startSeconds, fps);
                const durationInFrames = Math.max(1, secondsToFrames(plannedEndSeconds - shot.startSeconds, fps));
                const shotScene = withShotPlan(directedScene, renderedShot);
                return (
                  <Sequence key={shot.id} from={from} durationInFrames={durationInFrames} name={shot.id}>
                    <ShotLayer scene={shotScene} shot={renderedShot} durationInFrames={durationInFrames} />
                  </Sequence>
                );
              }) : <ShotLayer scene={directedScene} durationInFrames={sceneRange.durationInFrames} />}
              <CaptionOverlay chunks={captionChunks} offsetSeconds={lineTiming?.startSeconds ?? 0} theme={directedScene.visualPlan?.referenceStyle ? 'reference' : directedScene.visualStyle === 'voice-studio' || directedScene.visualStyle === 'voice-studio-3d' ? 'voice-studio' : 'default'} />
            </SceneLayer>
          </Sequence>
        );
      })}
      {mixPath ? <Audio src={staticFile(mixPath)} /> : narrationPath ? <Audio src={staticFile(narrationPath)} /> : null}
      {!mixPath && project.music.mode === 'file' && (musicPath ?? project.music.path) ? <Audio src={staticFile(musicPath ?? project.music.path!)} /> : null}
    </AbsoluteFill>
  );
}

function withShotPlan(scene: ProjectScene, shot: ShotTimelineSegment): ProjectScene {
  const plan = scene.visualPlan;
  if (!plan) return scene;
  return {
    ...scene,
    visualPlan: {
      ...plan,
      shotType: shot.shotType,
      uiComponent: shot.uiComponent ?? plan.uiComponent,
      subject: shot.objectLabel ?? plan.subject,
      action: shot.objectLabel ? `animate ${shot.objectLabel}` : plan.action,
      heading: shot.heading ?? plan.heading,
      camera: shot.camera.preset,
    },
  };
}

function ShotLayer({scene, shot, durationInFrames}: {scene: ProjectScene; shot?: ShotTimelineSegment; durationInFrames: number}) {
  const renderer = scene.visualPlan?.renderer ?? scene.visualStyle;
  const content = renderer === 'three-proof' ? <ThreeProofScene scene={scene} /> : renderer === 'stick-story' || renderer === 'claude-animation' ? <StickStoryScene scene={scene} /> : renderer === 'voice-studio-3d' ? <VoiceStudio3DScene scene={scene} shot={shot} durationInFrames={durationInFrames} /> : renderer === 'motion-graphics' ? <MotionGraphicsScene scene={scene} shot={shot} durationInFrames={durationInFrames} /> : renderer === 'voice-studio' ? <VoiceStudioScene scene={scene} /> : <InsideOutScene scene={scene} />;
  const frame = useCurrentFrame();
  return <AbsoluteFill>{content}{shot ? <SceneTransition kind={shot.transition} frame={frame} durationInFrames={durationInFrames} /> : null}</AbsoluteFill>;
}

function SceneLayer({scene, durationInFrames, hasShotTimeline, children}: {scene: ProjectScene; durationInFrames: number; hasShotTimeline: boolean; children: ReactNode}) {
  const frame = useCurrentFrame();
  return <AbsoluteFill>{children}{!hasShotTimeline ? <SceneTransition kind={scene.transition as 'cut' | 'fade' | 'crossfade' | 'flash' | 'slide' | 'zoom'} frame={frame} durationInFrames={durationInFrames} /> : null}</AbsoluteFill>;
}

type ProjectScene = ReturnType<typeof parseProject>['scenes'][number];
