import {ThreeCanvas} from '@remotion/three';
import {useFrame, useThree} from '@react-three/fiber';
import {createContext, useContext} from 'react';
import type {ReactNode} from 'react';
import {AbsoluteFill, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Scene, ShotTimelineSegment, VisualPlan} from '../types/project';
import {GltfCharacter} from '../engines/visuals/gltfCharacter';
import {isReferenceStyle} from './referenceStyleProfiles';

const palette = {
  wall: '#2B2020',
  floor: '#17151A',
  wood: '#5A382B',
  panel: '#29242C',
  orange: '#E9855B',
  orangeLight: '#FFB07E',
  gold: '#F1C66D',
  cream: '#F5E9D1',
  green: '#75C898',
  blue: '#77A7FF',
};

const ReferenceStyleContext = createContext<string | undefined>(undefined);

type ShotType = VisualPlan['shotType'];

type ShotConfig = {position: [number, number, number]; fov: number; target: string};

type Point = [number, number, number];

const targetPoints: Record<string, Point> = {
  studio: [0, 0, 0],
  presenter: [-0.3, 0.15, 0.3],
  desk: [-0.8, -0.25, 0.3],
  microphone: [0.05, 0.1, 0.6],
  headphones: [0, 0.25, 0.7],
  diagram: [0, 0.2, 0.4],
  comparison: [0, 0.2, 0.7],
  data: [0, 0.2, 0.7],
  process: [0, 0.2, 0.4],
};

function targetPoint(name: string): Point {
  return targetPoints[name] ?? targetPoints.studio;
}

function lerpPoint(from: Point, to: Point, amount: number): Point {
  return [from[0] + (to[0] - from[0]) * amount, from[1] + (to[1] - from[1]) * amount, from[2] + (to[2] - from[2]) * amount];
}

function cameraPath(base: Point, movement: ShotTimelineSegment['camera']['movement'], amount: number): Point {
  const start = movement === 'reveal' ? [base[0] + 2.2, base[1] + 0.15, base[2] + 0.4] as Point : base;
  const end = movement === 'push-in' ? [base[0], base[1], base[2] - 1.2] as Point : movement === 'pull-out' ? [base[0], base[1] + 0.15, base[2] + 1.3] as Point : movement === 'pan-left' ? [base[0] - 0.8, base[1], base[2]] as Point : movement === 'pan-right' ? [base[0] + 0.8, base[1], base[2]] as Point : base;
  return lerpPoint(start, end, amount);
}

function defaultMovement(shotType: ShotType): ShotTimelineSegment['camera']['movement'] {
  if (shotType === 'split-screen') return 'pan-right';
  if (shotType === 'reaction' || shotType === 'permission-wide') return 'pull-out';
  if (shotType === 'diagram') return 'reveal';
  return shotType === 'hook-wide' ? 'push-in' : 'push-in';
}

const shotConfig: Record<ShotType, ShotConfig> = {
  'hook-wide': {position: [0, 1.4, 10.8], fov: 45, target: 'studio'},
  'character-close': {position: [-0.15, 1.15, 4.8], fov: 38, target: 'presenter'},
  'ui-demo': {position: [0.1, 1.35, 6.55], fov: 44, target: 'desk'},
  'object-close': {position: [0.35, 0.95, 4.8], fov: 38, target: 'microphone'},
  reaction: {position: [-0.25, 1.15, 5.1], fov: 40, target: 'presenter'},
  diagram: {position: [0, 1.45, 7.2], fov: 48, target: 'diagram'},
  'permission-wide': {position: [0, 1.4, 10.2], fov: 45, target: 'studio'},
  'split-screen': {position: [0, 1.25, 7.4], fov: 43, target: 'comparison'},
  'data-viz': {position: [0.2, 1.2, 6.8], fov: 44, target: 'data'},
  process: {position: [0, 1.35, 7.1], fov: 46, target: 'process'},
};

export function VoiceStudio3DScene({scene, shot, durationInFrames}: {scene: Scene; shot?: ShotTimelineSegment; durationInFrames?: number}) {
  const frame = useCurrentFrame();
  const {width, height, durationInFrames: compositionDuration} = useVideoConfig();
  const plan = scene.visualPlan;
  const number = (plan?.stepIndex ?? (Number(scene.id.replace(/\D/g, '')) || 1) - 1) + 1;
  const shotType = shot?.shotType ?? plan?.shotType ?? (number === 1 ? 'hook-wide' : 'ui-demo');
  const config = shotConfig[shotType];
  const localDuration = Math.max(2, durationInFrames ?? compositionDuration);
  const progress = interpolate(frame, [0, localDuration - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const movement = shot?.camera.movement ?? defaultMovement(shotType);
  const cameraPosition = cameraPath(config.position, movement, progress);
  const fromFocus = targetPoint(shot?.focus.from ?? shot?.camera.target ?? config.target);
  const toFocus = targetPoint(shot?.focus.to ?? shot?.camera.target ?? config.target);
  const cameraTarget = lerpPoint(fromFocus, toFocus, progress);

  return (
    <AbsoluteFill style={{backgroundColor: palette.floor}}>
      <ReferenceStyleContext.Provider value={plan?.referenceStyle}>
        <ThreeCanvas width={width} height={height} camera={{fov: config.fov, position: cameraPosition}} shadows style={{backgroundColor: isReferenceStyle(plan?.referenceStyle, 'snapinsta-cinematic-3d') ? '#1E1124' : palette.wall}}>
          <CameraRig position={cameraPosition} target={cameraTarget} />
          <color attach="background" args={[isReferenceStyle(plan?.referenceStyle, 'snapinsta-cinematic-3d') ? '#1E1124' : shotType === 'diagram' || shotType === 'process' ? '#101722' : palette.wall]} />
        <ambientLight intensity={shotType === 'diagram' || shotType === 'process' ? 0.6 : 0.42} color="#FFD9BD" />
        <directionalLight castShadow position={[-4, 6, 5]} intensity={2.5} color="#FFD1A3" shadow-mapSize={[1024, 1024]} />
        <pointLight position={[3, 2.5, 2]} intensity={shotType === 'object-close' ? 11 : 8} distance={8} color="#E9855B" />
        <pointLight position={[-3, 4, 1]} intensity={shotType === 'diagram' || shotType === 'process' ? 7 : 4} distance={9} color="#6E93FF" />
        {isReferenceStyle(plan?.referenceStyle, 'snapinsta-cinematic-3d') ? <pointLight position={[0, 2.8, -0.5]} intensity={5} distance={7} color="#F14DBB" /> : null}
        <ShotGeometry shotType={shotType} shot={shot} frame={frame} sceneNumber={number} progress={progress} characterModelPath={scene.assets?.characterModelPath} />
        </ThreeCanvas>
      </ReferenceStyleContext.Provider>
      <ShotOverlay shotType={shotType} sceneNumber={number} plan={plan} shot={shot} screenRecording={scene.screenRecording} progress={progress} frame={frame} durationInFrames={localDuration} />
    </AbsoluteFill>
  );
}

function CameraRig({position, target}: {position: Point; target: Point}) {
  const {camera} = useThree();
  useFrame(() => {
    camera.position.set(position[0], position[1], position[2]);
    camera.lookAt(target[0], target[1], target[2]);
    camera.updateProjectionMatrix();
  });
  return null;
}

function ShotGeometry({shotType, shot, frame, sceneNumber, progress, characterModelPath}: {shotType: ShotType; shot?: ShotTimelineSegment; frame: number; sceneNumber: number; progress: number; characterModelPath?: string}) {
  if (shotType === 'diagram' || shotType === 'process') return <DiagramGeometry frame={frame} progress={progress} process={shotType === 'process'} />;
  if (shotType === 'split-screen') return <SplitScreenGeometry frame={frame} progress={progress} />;
  if (shotType === 'data-viz') return <DataVizGeometry frame={frame} progress={progress} />;
  if (shotType === 'object-close') return <ObjectCloseGeometry frame={frame} progress={progress} objectKind={shot?.objectKind ?? 'microphone'} />;
  if (shotType === 'character-close' || shotType === 'reaction') return <CharacterGeometry frame={frame} sceneNumber={sceneNumber} characterModelPath={characterModelPath} reaction={shotType === 'reaction'} />;
  return <StudioGeometry frame={frame} sceneNumber={sceneNumber} progress={progress} characterModelPath={characterModelPath} permission={shotType === 'permission-wide'} />;
}

function StudioGeometry({frame, sceneNumber, progress, characterModelPath, permission}: {frame: number; sceneNumber: number; progress: number; characterModelPath?: string; permission: boolean}) {
  const reference = isReferenceStyle(useContext(ReferenceStyleContext), 'snapinsta-cinematic-3d');
  const orbPulse = 1 + Math.sin(frame / 11) * 0.035;
  const presenterBob = Math.sin(frame / 26) * 0.035;
  const gesture = sceneNumber === 4 ? Math.sin(frame / 8) * 0.25 : sceneNumber === 7 ? Math.sin(frame / 7) * 0.12 : 0;
  return <>
    <StudioBackdrop />
    <mesh castShadow receiveShadow position={[-0.8, -0.85, 0.2]}><boxGeometry args={[4.8, 0.35, 1.5]} /><meshStandardMaterial color={palette.wood} roughness={0.55} /></mesh>
    <mesh castShadow position={[-0.8, -1.25, 0.2]}><boxGeometry args={[4.35, 0.55, 1.1]} /><meshStandardMaterial color="#3D2525" roughness={0.75} /></mesh>
    <Laptop position={[-2.3, -0.35, 0.1]} />
    <Microphone position={[0.05, 0.15, 0.5]} />
    <Fan position={[3.0, -0.6, 0.5]} frame={frame} />
    {reference ? <ReferencePresenter position={[-1.45, -0.95, 0.35]} bob={presenterBob} gesture={gesture} /> : characterModelPath ? <GltfCharacter url={characterModelPath} state={sceneNumber === 4 ? 'record' : sceneNumber === 6 ? 'talk' : 'idle'} position={[-1.45, -1.18, 0.35]} scale={0.62} /> : <Presenter position={[-1.45, -1.18, 0.35]} bob={presenterBob} gesture={gesture} />}
    {reference ? <ReferenceCompanion position={[1.7, -0.95, 0.45]} frame={frame} /> : <VoiceOrb position={permission ? [1.2, 1.2, 0.45] : [1.65, 1.15, 0.45]} pulse={orbPulse} angle={frame / 28} />}
    <mesh position={[0, -1.65, 2.5]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[7, 0.05]} /><meshBasicMaterial color={palette.orange} transparent opacity={0.22 + progress * 0.1} /></mesh>
  </>;
}

function StudioBackdrop() {
  const referenceStyle = useContext(ReferenceStyleContext);
  const reference = isReferenceStyle(referenceStyle, 'snapinsta-cinematic-3d');
  return <>
    <mesh receiveShadow position={[0, -1.7, 0]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[14, 14]} /><meshStandardMaterial color={reference ? '#160E18' : palette.floor} roughness={0.9} /></mesh>
    <mesh receiveShadow position={[0, 2.2, -1.5]}><boxGeometry args={[8, 7.5, 0.25]} /><meshStandardMaterial color={reference ? '#241326' : palette.wall} roughness={0.85} /></mesh>
    {reference ? <ReferenceWindow /> : <><AcousticPanel position={[-2.6, 2.2, -1.25]} scale={[1.2, 1.5, 0.12]} /><AcousticPanel position={[-0.9, 3.2, -1.25]} scale={[1.45, 1.1, 0.12]} /><AcousticPanel position={[1.2, 2.8, -1.25]} scale={[1.7, 1.3, 0.12]} /><AcousticPanel position={[2.9, 3.6, -1.25]} scale={[0.8, 1.8, 0.12]} /></>}
  </>;
}

function ReferenceWindow() {
  return <group position={[0, 2.3, -1.32]}>
    <mesh><boxGeometry args={[6.6, 3.7, 0.08]} /><meshBasicMaterial color="#8C3C63" /></mesh>
    <mesh position={[0, 0, 0.06]}><boxGeometry args={[6.2, 3.25, 0.03]} /><meshBasicMaterial color="#D87983" transparent opacity={0.8} /></mesh>
    <mesh position={[0, -0.65, 0.08]}><boxGeometry args={[6.2, 1.15, 0.03]} /><meshBasicMaterial color="#F29A68" transparent opacity={0.82} /></mesh>
    <mesh position={[0, 0, 0.12]}><boxGeometry args={[0.08, 3.3, 0.05]} /><meshBasicMaterial color="#261A39" /></mesh>
    <mesh position={[-3.1, 0, 0.12]}><boxGeometry args={[0.08, 3.3, 0.05]} /><meshBasicMaterial color="#261A39" /></mesh>
    <mesh position={[3.1, 0, 0.12]}><boxGeometry args={[0.08, 3.3, 0.05]} /><meshBasicMaterial color="#261A39" /></mesh>
    {[-2.3, -1.5, -0.7, 0.1, 0.9, 1.7, 2.5].map((x) => <mesh key={x} position={[x, 1.22, 0.2]}><sphereGeometry args={[0.07, 10, 8]} /><meshBasicMaterial color="#FFD27A" /></mesh>)}
  </group>;
}

function CharacterGeometry({frame, sceneNumber, characterModelPath, reaction}: {frame: number; sceneNumber: number; characterModelPath?: string; reaction: boolean}) {
  const reference = isReferenceStyle(useContext(ReferenceStyleContext), 'snapinsta-cinematic-3d');
  const bob = Math.sin(frame / 18) * 0.04;
  const gesture = reaction ? Math.sin(frame / 8) * 0.42 : Math.sin(frame / 14) * 0.18;
  return <>
    <StudioBackdrop />
    <mesh position={[0, -1.7, 1.4]} rotation={[-Math.PI / 2, 0, 0]}><circleGeometry args={[3.7, 48]} /><meshBasicMaterial color={reaction ? '#3A2530' : '#242A36'} transparent opacity={0.8} /></mesh>
    {reference ? <ReferencePresenter position={[-0.3, -0.85, 0.3]} bob={bob} gesture={gesture} /> : characterModelPath ? <GltfCharacter url={characterModelPath} state={reaction ? 'talk' : sceneNumber === 4 ? 'record' : 'talk'} position={[-0.3, -1.05, 0.3]} scale={0.52} /> : <Presenter position={[-0.3, -1.05, 0.3]} bob={bob} gesture={gesture} />}
    {reference ? <ReferenceCompanion position={[1.55, -0.85, 0.55]} frame={frame} /> : <Microphone position={[1.25, -0.1, 0.6]} />}
    {reference ? null : <VoiceOrb position={[-1.45, 1.25, 0.4]} pulse={1 + Math.sin(frame / 10) * 0.05} angle={frame / 20} />}
    {reaction ? <ReactionRings frame={frame} /> : null}
  </>;
}

function ObjectCloseGeometry({frame, progress, objectKind}: {frame: number; progress: number; objectKind: ShotTimelineSegment['objectKind']}) {
  return <>
    <StudioBackdrop />
    <mesh castShadow position={[1.25, -1.3, 0.2]} rotation={[0, 0, -0.08]}><boxGeometry args={[4.2, 0.22, 1.3]} /><meshStandardMaterial color={palette.wood} roughness={0.55} /></mesh>
    {objectKind === 'headphones' ? <Headphones frame={frame} /> : <Microphone position={[0, -0.15, 0.7]} />}
    <VoiceOrb position={[1.65, 1.25, 0.55]} pulse={1 + Math.sin(frame / 9) * 0.06} angle={frame / 18} />
    <Laptop position={[-1.4, -0.55, 0.3]} />
    <mesh position={[0.45, -1.58, 2.5]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[6, 0.06]} /><meshBasicMaterial color={palette.gold} transparent opacity={0.3 + progress * 0.2} /></mesh>
  </>;
}

function Headphones({frame}: {frame: number}) {
  return <group position={[0, 0.35, 0.9]} scale={0.62} rotation={[0, Math.sin(frame / 48) * 0.08, 0]}>
    <mesh rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[1.2, 0.11, 16, 64]} /><meshStandardMaterial color={palette.orangeLight} emissive="#6B2D36" emissiveIntensity={0.45} metalness={0.15} /></mesh>
    <mesh position={[-0.92, -0.05, 0]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.42, 0.42, 0.3, 32]} /><meshStandardMaterial color="#334F78" metalness={0.25} roughness={0.4} /></mesh>
    <mesh position={[0.92, -0.05, 0]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.42, 0.42, 0.3, 32]} /><meshStandardMaterial color="#A84A3B" metalness={0.25} roughness={0.4} /></mesh>
    <mesh position={[-0.92, -0.05, 0.18]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.3, 0.05, 12, 32]} /><meshBasicMaterial color={palette.blue} /></mesh>
    <mesh position={[0.92, -0.05, 0.18]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.3, 0.05, 12, 32]} /><meshBasicMaterial color={palette.orange} /></mesh>
    <mesh rotation={[Math.PI / 2, 0, frame / 44]}><torusGeometry args={[1.55, 0.025, 10, 64]} /><meshBasicMaterial color={palette.gold} transparent opacity={0.65} /></mesh>
  </group>;
}

function SplitScreenGeometry({frame, progress}: {frame: number; progress: number}) {
  const reference = isReferenceStyle(useContext(ReferenceStyleContext), 'snapinsta-cinematic-3d');
  return <>
    <StudioBackdrop />
    <mesh position={[-1.8, 0.2, 0.5]}><boxGeometry args={[2.9, 3.6, 0.2]} /><meshStandardMaterial color="#202A38" emissive="#0A1628" emissiveIntensity={0.4} /></mesh>
    <mesh position={[1.8, 0.2, 0.5]}><boxGeometry args={[2.9, 3.6, 0.2]} /><meshStandardMaterial color="#3A2730" emissive="#2B1118" emissiveIntensity={0.4} /></mesh>
    <mesh position={[0, 0.2, 0.8]}><boxGeometry args={[0.05, 4.2, 0.08]} /><meshBasicMaterial color={palette.gold} transparent opacity={0.55 + progress * 0.3} /></mesh>
    {reference ? <SignalDot position={[-1.8, 0.65, 1]} color={palette.blue} /> : <VoiceOrb position={[-1.8, 0.65, 1]} pulse={1 + Math.sin(frame / 12) * 0.04} angle={frame / 24} />}
    {reference ? <SignalDot position={[1.8, 0.65, 1]} color={palette.orange} /> : <VoiceOrb position={[1.8, 0.65, 1]} pulse={1 + Math.sin(frame / 9) * 0.07} angle={-frame / 18} />}
    <mesh position={[-1.8, -1.25, 1]}><boxGeometry args={[1.7, 0.06, 0.05]} /><meshBasicMaterial color={palette.blue} /></mesh>
    <mesh position={[1.8, -1.25, 1]}><boxGeometry args={[1.7, 0.06, 0.05]} /><meshBasicMaterial color={palette.orange} /></mesh>
  </>;
}

function DataVizGeometry({frame, progress}: {frame: number; progress: number}) {
  const reference = isReferenceStyle(useContext(ReferenceStyleContext), 'snapinsta-cinematic-3d');
  const heights = [0.8, 1.5, 2.1, 1.2, 2.7, 1.9];
  return <>
    <StudioBackdrop />
    {heights.map((height, index) => <mesh key={index} position={[-2.8 + index * 1.05, -1.65 + height / 2, 0.7]} scale={[0.65, height * (0.82 + progress * 0.18 + Math.sin(frame / 14 + index) * 0.05), 0.35]}><boxGeometry args={[1, 1, 1]} /><meshStandardMaterial color={index % 2 ? palette.orange : palette.blue} emissive={index % 2 ? '#6C2B1C' : '#153C6D'} emissiveIntensity={0.45} /></mesh>)}
    <mesh position={[0, -1.68, 0.7]}><boxGeometry args={[7.2, 0.06, 0.7]} /><meshBasicMaterial color={palette.cream} transparent opacity={0.55} /></mesh>
    {reference ? <ReferenceCompanion position={[0, 1.5, 0.8]} frame={frame} /> : <VoiceOrb position={[0, 2.0, 0.8]} pulse={1 + Math.sin(frame / 10) * 0.04} angle={frame / 20} />}
  </>;
}

function DiagramGeometry({frame, progress, process}: {frame: number; progress: number; process: boolean}) {
  const reference = isReferenceStyle(useContext(ReferenceStyleContext), 'snapinsta-cinematic-3d');
  const pulse = 1 + Math.sin(frame / 12) * 0.04;
  return <>
    <mesh receiveShadow position={[0, -1.7, 0]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[14, 14]} /><meshStandardMaterial color="#101722" roughness={0.82} /></mesh>
    <mesh position={[0, 2.3, -1.5]}><boxGeometry args={[8, 7.5, 0.2]} /><meshStandardMaterial color={process ? '#172A31' : '#16263A'} roughness={0.9} /></mesh>
    {reference ? <ReferenceCompanion position={[-0.95, 0.2, 0.4]} frame={frame} /> : <VoiceOrb position={[-0.95, 0.2, 0.4]} pulse={pulse} angle={frame / 22} />}
    <mesh position={[0, 0.2, 0.4]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.035, 0.035, 2.3, 8]} /><meshBasicMaterial color={palette.blue} transparent opacity={0.45 + progress * 0.4} /></mesh>
    <mesh position={[2.2, 0.2, 0.4]}><boxGeometry args={[1.5, 1.5, 0.28]} /><meshStandardMaterial color="#274F6A" emissive="#102A4A" emissiveIntensity={0.6} /></mesh>
    <mesh position={[2.2, 1.05, 0.4]}><boxGeometry args={[1.1, 0.06, 0.05]} /><meshBasicMaterial color={palette.cream} /></mesh>
    <mesh position={[2.2, 0.78, 0.4]}><boxGeometry args={[0.75, 0.05, 0.05]} /><meshBasicMaterial color={palette.orangeLight} /></mesh>
  </>;
}

function ReactionRings({frame}: {frame: number}) {
  const scale = 1 + interpolate(frame % 36, [0, 35], [0, 0.45], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <group position={[-0.3, 1.15, 0.35]} scale={scale}><mesh><torusGeometry args={[1.45, 0.035, 12, 64]} /><meshBasicMaterial color={palette.gold} transparent opacity={0.55} /></mesh><mesh rotation={[0, Math.PI / 2, 0]}><torusGeometry args={[1.1, 0.025, 12, 64]} /><meshBasicMaterial color={palette.orange} transparent opacity={0.5} /></mesh></group>;
}

function AcousticPanel({position, scale}: {position: [number, number, number]; scale: [number, number, number]}) {
  return <mesh receiveShadow position={position} scale={scale}><boxGeometry args={[1, 1, 1]} /><meshStandardMaterial color={palette.panel} roughness={0.95} /></mesh>;
}

function SignalDot({position, color}: {position: [number, number, number]; color: string}) {
  return <mesh position={position}><sphereGeometry args={[0.32, 24, 16]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} roughness={0.35} /></mesh>;
}

function ReferencePresenter({position, bob, gesture}: {position: [number, number, number]; bob: number; gesture: number}) {
  return <group position={position} rotation={[0, 0, bob]}>
    <mesh castShadow position={[0, 1.52, 0]}><sphereGeometry args={[0.58, 40, 28]} /><meshStandardMaterial color="#F0B28E" roughness={0.58} /></mesh>
    <mesh castShadow position={[0, 1.77, -0.02]} scale={[1.02, 0.58, 0.9]}><sphereGeometry args={[0.58, 40, 28]} /><meshStandardMaterial color="#7A3027" roughness={0.55} /></mesh>
    <mesh castShadow position={[-0.42, 1.58, 0.02]} scale={[0.32, 0.7, 0.9]}><sphereGeometry args={[0.58, 32, 24]} /><meshStandardMaterial color="#7A3027" roughness={0.58} /></mesh>
    <mesh castShadow position={[0.42, 1.58, 0.02]} scale={[0.32, 0.7, 0.9]}><sphereGeometry args={[0.58, 32, 24]} /><meshStandardMaterial color="#7A3027" roughness={0.58} /></mesh>
    <mesh position={[-0.2, 1.58, 0.48]}><sphereGeometry args={[0.1, 20, 16]} /><meshStandardMaterial color="#FFF8EF" roughness={0.25} /></mesh>
    <mesh position={[0.2, 1.58, 0.48]}><sphereGeometry args={[0.1, 20, 16]} /><meshStandardMaterial color="#FFF8EF" roughness={0.25} /></mesh>
    <mesh position={[-0.2, 1.58, 0.57]}><sphereGeometry args={[0.045, 16, 12]} /><meshStandardMaterial color="#24202A" roughness={0.28} /></mesh>
    <mesh position={[0.2, 1.58, 0.57]}><sphereGeometry args={[0.045, 16, 12]} /><meshStandardMaterial color="#24202A" roughness={0.28} /></mesh>
    <mesh position={[0, 1.33, 0.55]} scale={[0.14, 0.07, 0.04]}><sphereGeometry args={[0.4, 20, 14]} /><meshStandardMaterial color="#7E2E35" roughness={0.35} /></mesh>
    <mesh castShadow position={[0, 0.28, 0]} scale={[0.78, 1.05, 0.5]}><capsuleGeometry args={[0.5, 1.25, 12, 24]} /><meshStandardMaterial color="#F4F1E8" roughness={0.7} /></mesh>
    <mesh castShadow position={[0, 0.67, 0.34]} rotation={[0, 0, Math.PI]}><coneGeometry args={[0.22, 0.72, 4]} /><meshStandardMaterial color="#D63F47" roughness={0.52} /></mesh>
    <mesh castShadow position={[-0.7, 0.28, 0]} rotation={[0, 0, -0.72 + gesture]}><capsuleGeometry args={[0.11, 0.95, 10, 16]} /><meshStandardMaterial color="#F0B28E" roughness={0.6} /></mesh>
    <mesh castShadow position={[0.7, 0.32, 0]} rotation={[0, 0, 0.68 - gesture]}><capsuleGeometry args={[0.11, 0.95, 10, 16]} /><meshStandardMaterial color="#F0B28E" roughness={0.6} /></mesh>
  </group>;
}

function ReferenceCompanion({position, frame}: {position: [number, number, number]; frame: number}) {
  return <group position={position} scale={0.72 + Math.sin(frame / 24) * 0.015}>
    {[0, 1, 2, 3, 4, 5].map((index) => { const angle = index * Math.PI / 3; return <mesh key={index} castShadow position={[Math.cos(angle) * 0.42, 0.35 + Math.sin(angle) * 0.18, 0]} scale={[0.5, 0.38, 0.38]}><sphereGeometry args={[0.52, 28, 20]} /><meshStandardMaterial color="#F0A06D" roughness={0.62} /></mesh>; })}
    <mesh castShadow position={[0, 0.35, 0.08]}><sphereGeometry args={[0.48, 32, 24]} /><meshStandardMaterial color="#F7B97E" roughness={0.58} /></mesh>
    <mesh position={[-0.16, 0.4, 0.46]}><sphereGeometry args={[0.08, 18, 14]} /><meshStandardMaterial color="#28212B" roughness={0.25} /></mesh>
    <mesh position={[0.16, 0.4, 0.46]}><sphereGeometry args={[0.08, 18, 14]} /><meshStandardMaterial color="#28212B" roughness={0.25} /></mesh>
    <mesh position={[0, 0.2, 0.47]} scale={[0.16, 0.06, 0.03]}><sphereGeometry args={[0.35, 16, 12]} /><meshStandardMaterial color="#7C3540" roughness={0.35} /></mesh>
  </group>;
}

function Presenter({position, bob, gesture}: {position: [number, number, number]; bob: number; gesture: number}) {
  return <group position={position} rotation={[0, 0, bob]}>
    <mesh castShadow position={[0, 1.25, 0]}><sphereGeometry args={[0.55, 24, 16]} /><meshStandardMaterial color="#9A5A3C" roughness={0.75} /></mesh>
    <mesh castShadow position={[0, 1.28, 0.02]} scale={[1.02, 0.35, 0.8]}><sphereGeometry args={[0.55, 24, 16]} /><meshStandardMaterial color="#17151A" roughness={0.85} /></mesh>
    <mesh castShadow position={[0, 0.1, 0]} scale={[0.8, 1.1, 0.5]}><capsuleGeometry args={[0.48, 1.25, 8, 16]} /><meshStandardMaterial color="#1E463E" roughness={0.8} /></mesh>
    <mesh castShadow position={[-0.75, 0.15, 0]} rotation={[0, 0, -0.7 + gesture]}><capsuleGeometry args={[0.12, 1.0, 8, 12]} /><meshStandardMaterial color="#9A5A3C" roughness={0.8} /></mesh>
    <mesh castShadow position={[0.75, 0.2, 0]} rotation={[0, 0, 0.65 - gesture]}><capsuleGeometry args={[0.12, 1.0, 8, 12]} /><meshStandardMaterial color="#9A5A3C" roughness={0.8} /></mesh>
    <mesh castShadow position={[-0.45, -1.15, 0]} rotation={[0, 0, -0.15]}><capsuleGeometry args={[0.15, 1.3, 8, 12]} /><meshStandardMaterial color="#191A22" roughness={0.85} /></mesh>
    <mesh castShadow position={[0.45, -1.15, 0]} rotation={[0, 0, 0.15]}><capsuleGeometry args={[0.15, 1.3, 8, 12]} /><meshStandardMaterial color="#191A22" roughness={0.85} /></mesh>
  </group>;
}

function VoiceOrb({position, pulse, angle}: {position: [number, number, number]; pulse: number; angle: number}) {
  return <group position={position} scale={pulse}>
    <mesh castShadow><sphereGeometry args={[0.95, 32, 20]} /><meshStandardMaterial color={palette.orange} emissive="#5B211D" emissiveIntensity={0.65} roughness={0.34} metalness={0.12} /></mesh>
    <mesh position={[0, 0, 0.78]}><circleGeometry args={[0.64, 32]} /><meshStandardMaterial color="#070A0E" roughness={0.6} /></mesh>
    <mesh position={[-0.2, 0.14, 0.86]}><boxGeometry args={[0.12, 0.08, 0.03]} /><meshBasicMaterial color={palette.cream} /></mesh>
    <mesh position={[0.2, 0.14, 0.86]}><boxGeometry args={[0.12, 0.08, 0.03]} /><meshBasicMaterial color={palette.cream} /></mesh>
    <mesh rotation={[Math.PI / 2, 0, angle]}><torusGeometry args={[1.25, 0.035, 12, 64]} /><meshStandardMaterial color="#E4A072" emissive="#7E3B2D" emissiveIntensity={0.5} /></mesh>
    <mesh rotation={[Math.PI / 2, angle, 0]}><torusGeometry args={[1.12, 0.025, 12, 64]} /><meshStandardMaterial color="#D47B54" /></mesh>
    <mesh position={[0, 1.18, 0]}><sphereGeometry args={[0.09, 12, 8]} /><meshBasicMaterial color="#FFD34F" /></mesh>
  </group>;
}

function Laptop({position}: {position: [number, number, number]}) {
  return <group position={position} rotation={[0.1, 0.2, -0.08]}><mesh castShadow><boxGeometry args={[1.1, 0.7, 0.06]} /><meshStandardMaterial color="#A9B5B6" roughness={0.35} metalness={0.25} /></mesh><mesh position={[0, -0.38, 0.25]} rotation={[0.3, 0, 0]}><boxGeometry args={[1.35, 0.08, 0.75]} /><meshStandardMaterial color="#515963" roughness={0.7} /></mesh></group>;
}

function Microphone({position}: {position: [number, number, number]}) {
  return <group position={position}><mesh castShadow position={[0, 0.5, 0]}><capsuleGeometry args={[0.16, 0.7, 8, 12]} /><meshStandardMaterial color="#B9B5AB" roughness={0.5} metalness={0.2} /></mesh><mesh position={[0, -0.25, 0]}><cylinderGeometry args={[0.025, 0.025, 1.7, 8]} /><meshStandardMaterial color="#17151A" /></mesh><mesh position={[0, -1.1, 0]}><boxGeometry args={[0.8, 0.04, 0.35]} /><meshStandardMaterial color="#17151A" /></mesh></group>;
}

function Fan({position, frame}: {position: [number, number, number]; frame: number}) {
  return <group position={position}><mesh><cylinderGeometry args={[0.7, 0.7, 0.08, 32]} /><meshStandardMaterial color="#37383D" roughness={0.8} /></mesh><mesh position={[0, 0, 0.08]} rotation={[0, 0, frame / 12]}><torusGeometry args={[0.48, 0.025, 8, 32]} /><meshBasicMaterial color="#9EA0A4" /></mesh><mesh position={[0, -1.0, 0]}><cylinderGeometry args={[0.05, 0.05, 2, 10]} /><meshStandardMaterial color="#77787C" /></mesh></group>;
}

function ShotOverlay({shotType, sceneNumber, plan, shot, screenRecording, progress, frame, durationInFrames}: {shotType: ShotType; sceneNumber: number; plan?: VisualPlan; shot?: ShotTimelineSegment; screenRecording?: {assetPath?: string}; progress: number; frame: number; durationInFrames: number}) {
  const enterFrames = Math.min(12, Math.max(3, Math.floor(durationInFrames * 0.18)));
  const exitFrames = Math.min(12, Math.max(3, Math.floor(durationInFrames * 0.14)));
  const entrance = shot?.overlay.entrance ?? 'fade';
  const exit = shot?.overlay.exit ?? 'fade';
  const opacityIn = entrance === 'cut' ? 1 : interpolate(frame, [0, enterFrames], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const opacityOut = exit === 'cut' ? 1 : interpolate(frame, [durationInFrames - exitFrames, durationInFrames - 1], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const translate = entrance === 'rise' ? interpolate(frame, [0, enterFrames], [24, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : exit === 'drop' ? interpolate(frame, [durationInFrames - exitFrames, durationInFrames - 1], [0, 18], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  const scale = entrance === 'scale' ? interpolate(frame, [0, enterFrames], [0.94, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  let content: ReactNode;
  if (shotType === 'ui-demo') content = <UiOverlay sceneNumber={sceneNumber} plan={plan} shot={shot} screenRecording={screenRecording} progress={progress} />;
  else if (shotType === 'diagram' || shotType === 'process') content = <DiagramOverlay plan={plan} progress={progress} process={shotType === 'process'} />;
  else if (shotType === 'split-screen') content = <SplitScreenOverlay plan={plan} />;
  else if (shotType === 'data-viz') content = <DataVizOverlay plan={plan} progress={progress} />;
  else if (shotType === 'object-close') content = <ObjectOverlay plan={plan} progress={progress} />;
  else if (shotType === 'character-close') content = <CharacterOverlay plan={plan} />;
  else if (shotType === 'reaction') content = <ReactionOverlay plan={plan} frame={frame} />;
  else if (shotType === 'permission-wide') content = <PermissionOverlay plan={plan} />;
  else content = <HookOverlay sceneNumber={sceneNumber} plan={plan} />;
  return <div style={{position: 'absolute', inset: 0, pointerEvents: 'none', opacity: opacityIn * opacityOut, transform: `translateY(${translate}px) scale(${scale})`}}>{content}</div>;
}

function HookOverlay({sceneNumber, plan}: {sceneNumber: number; plan?: VisualPlan}) {
  return <div style={{position: 'absolute', top: '12%', left: '7%', right: '7%', color: palette.cream, fontFamily: 'Georgia, serif', fontSize: 58, fontWeight: 700, textShadow: '0 4px 12px #111'}}>{sceneNumber === 1 ? <>Voice, without<br /><span style={{color: palette.gold}}>the per-minute bill.</span></> : plan?.heading}<div style={{width: 330, height: 7, marginTop: 16, background: palette.orange, borderRadius: 4}} /></div>;
}

function CharacterOverlay({plan}: {plan?: VisualPlan}) {
  return <div style={{position: 'absolute', top: '13%', left: '7%', color: palette.cream, fontFamily: 'Arial, sans-serif', fontSize: 30, fontWeight: 800, letterSpacing: 2, textTransform: 'uppercase', textShadow: '0 3px 10px #111'}}><span style={{borderLeft: `7px solid ${palette.orange}`, paddingLeft: 14}}>{plan?.heading ?? 'Listen closely'}</span></div>;
}

function ReactionOverlay({plan, frame}: {plan?: VisualPlan; frame: number}) {
  const x = Math.sin(frame / 13) * 8;
  return <div style={{position: 'absolute', top: '17%', left: '8%', right: '8%', color: palette.cream, fontFamily: 'Georgia, serif', textAlign: 'center', transform: `translateY(${x}px)`}}><div style={{fontSize: 22, letterSpacing: 5, color: palette.gold}}>THE MOMENT IT CLICKS</div><div style={{fontSize: 54, fontWeight: 700, marginTop: 12, textShadow: '0 4px 14px #000'}}>{plan?.heading ?? 'That sounds real'}</div></div>;
}

function ObjectOverlay({plan, progress}: {plan?: VisualPlan; progress: number}) {
  return <div style={{position: 'absolute', left: '7%', right: '7%', bottom: '20%', display: 'flex', alignItems: 'center', gap: 18, color: palette.cream, fontFamily: 'Arial, sans-serif'}}><div style={{width: 16, height: 16, borderRadius: 50, background: palette.orange, boxShadow: `0 0 ${10 + progress * 18}px ${palette.orange}`}} /><div><div style={{fontSize: 18, letterSpacing: 3, color: palette.gold}}>SIGNAL</div><div style={{fontSize: 34, fontWeight: 800}}>{plan?.subject ?? 'Voice signal'}</div><div style={{fontSize: 18, color: '#D7C9C0', marginTop: 5}}>{plan?.action ?? 'Watch the waveform move'}</div></div></div>;
}

function SplitScreenOverlay({plan}: {plan?: VisualPlan}) {
  return <div style={{position: 'absolute', top: '12%', left: '6%', right: '6%', color: palette.cream, fontFamily: 'Arial, sans-serif', textAlign: 'center'}}><div style={{fontSize: 18, letterSpacing: 4, color: palette.gold}}>BEFORE / AFTER</div><div style={{fontSize: 42, fontWeight: 800, marginTop: 10}}>{plan?.heading ?? 'From words to a voice'}</div><div style={{display: 'flex', justifyContent: 'space-between', marginTop: 275, fontSize: 20, fontWeight: 800, letterSpacing: 2}}><span style={{color: palette.blue}}>INPUT</span><span style={{color: palette.orange}}>GENERATED</span></div></div>;
}

function DataVizOverlay({plan, progress}: {plan?: VisualPlan; progress: number}) {
  return <div style={{position: 'absolute', top: '13%', left: '7%', right: '7%', color: palette.cream, fontFamily: 'Arial, sans-serif'}}><div style={{fontSize: 18, letterSpacing: 4, color: palette.orange}}>SIGNAL ANALYSIS</div><div style={{fontSize: 42, fontWeight: 800, marginTop: 9}}>{plan?.heading ?? 'The model learns the pattern'}</div><div style={{marginTop: 16, width: `${35 + progress * 55}%`, height: 4, background: palette.orange, transformOrigin: 'left'}} /></div>;
}

function DiagramOverlay({plan, progress, process}: {plan?: VisualPlan; progress: number; process: boolean}) {
  const nodes = ['Text', 'Model', 'Voice'];
  return <div style={{position: 'absolute', top: '17%', left: '6%', right: '6%', color: palette.cream, fontFamily: 'Arial, sans-serif'}}><div style={{fontSize: 18, letterSpacing: 4, color: process ? palette.green : palette.blue}}>{process ? 'TEXT TO SPEECH' : 'THE PIPELINE'}</div><div style={{fontSize: 42, fontWeight: 800, margin: '8px 0 30px'}}>{plan?.heading ?? (process ? 'Words become sound' : 'The pipeline')}</div><div style={{display: 'flex', alignItems: 'center', gap: 8}}>{nodes.map((node, index) => <div key={node} style={{display: 'flex', alignItems: 'center', flex: index < nodes.length - 1 ? 1 : undefined}}><div style={{padding: '13px 16px', borderRadius: 12, background: index === 1 ? (process ? '#285E56' : '#274F6A') : '#202A38', border: `1px solid ${index === 1 ? (process ? palette.green : palette.blue) : '#596B83'}`, boxShadow: `0 ${4 + progress * 10}px 20px #0005`}}>{node}</div>{index < nodes.length - 1 ? <div style={{height: 3, flex: 1, margin: '0 8px', background: `linear-gradient(90deg, ${palette.blue}, ${palette.orange})`, transform: `scaleX(${progress})`, transformOrigin: 'left'}} /> : null}</div>)}</div></div>;
}

function PermissionOverlay({plan}: {plan?: VisualPlan}) {
  return <div style={{position: 'absolute', top: '15%', left: '7%', right: '7%', color: palette.cream, fontFamily: 'Arial, sans-serif'}}><div style={{display: 'inline-block', padding: '12px 16px', border: `2px solid ${palette.green}`, borderRadius: 999, color: palette.green, fontWeight: 800, letterSpacing: 2}}>VOICE RIGHTS</div><div style={{fontSize: 50, fontWeight: 800, marginTop: 18, maxWidth: 700}}>{plan?.heading ?? 'Use a voice with permission'}</div></div>;
}

function UiOverlay({sceneNumber, plan, shot, screenRecording, progress}: {sceneNumber: number; plan?: VisualPlan; shot?: ShotTimelineSegment; screenRecording?: {assetPath?: string}; progress: number}) {
  const title = plan?.heading ?? 'Explain the workflow';
  const maxHeight = `${shot?.overlay.maxHeightPercent ?? 23}%`;
  return <div style={{position: 'absolute', top: '17%', left: '42%', right: '5%', height: maxHeight, background: '#17161B', border: '2px solid #6D626A', borderRadius: 16, padding: '12px 14px', color: '#202027', fontFamily: 'Arial, sans-serif', boxSizing: 'border-box', boxShadow: '0 12px 22px #0008', overflow: 'hidden'}}>
    <div style={{display: 'flex', justifyContent: 'space-between', color: palette.orange, fontSize: 12, fontWeight: 900}}>STEP {Math.min(sceneNumber, 9)} <span style={{color: '#B6AEB4', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginLeft: 8}}>VoiceStudio · {title}</span></div>
    <div style={{display: 'flex', gap: 4, marginTop: 6}}>{Array.from({length: 7}, (_, i) => <div key={i} style={{height: 4, flex: 1, borderRadius: 5, background: i < sceneNumber - 1 ? palette.orange : '#514A55', transform: `scaleY(${i === sceneNumber - 1 ? 1.6 : 1})`}} />)}</div>
    <div style={{height: 22, marginTop: 9, background: '#F2EFE8', borderRadius: 5, color: '#777078', textAlign: 'center', fontSize: 9, paddingTop: 6, boxSizing: 'border-box'}}>● ● ● &nbsp; VoiceStudio / {title}</div>
    <div style={{marginTop: 0, background: '#FAFAF7', borderRadius: '0 0 8px 8px', minHeight: 0, height: 'calc(100% - 72px)', padding: 12, boxSizing: 'border-box', overflow: 'hidden'}}><div style={{fontFamily: 'Georgia, serif', color: '#1E1D24', fontSize: 20, fontWeight: 700, marginBottom: 8}}>{title}</div><UiPanel uiComponent={plan?.uiComponent ?? 'none'} screenRecording={screenRecording} progress={progress} /></div>
  </div>;
}

function UiPanel({uiComponent, screenRecording, progress}: {uiComponent: VisualPlan['uiComponent']; screenRecording?: {assetPath?: string}; progress: number}) {
  const dark = {fontFamily: 'Arial, sans-serif', fontSize: 15, color: '#24232A'} as const;
  if (uiComponent === 'screen-recording') return <div style={{...dark, padding: 0, overflow: 'hidden', borderRadius: 9, background: '#111'}}>{screenRecording?.assetPath ? <video src={staticFile(screenRecording.assetPath)} autoPlay muted loop playsInline style={{display: 'block', width: '100%', height: 250, objectFit: 'cover'}} /> : <div style={{height: 250, display: 'grid', placeItems: 'center', color: '#777'}}>Screen capture not staged</div>}</div>;
  if (uiComponent === 'download') return <div style={dark}><div style={{display: 'flex', justifyContent: 'space-between'}}><strong>Download voice model</strong><span style={{color: '#37845A'}}>Verified source</span></div><div style={{height: 28, marginTop: 18, background: '#E8E5DE', borderRadius: 8, overflow: 'hidden'}}><div style={{width: `${35 + progress * 55}%`, height: '100%', background: palette.orange}} /></div><div style={{display: 'flex', justifyContent: 'space-between', marginTop: 9, color: '#777078'}}><span>kokoro-v1.0.onnx</span><span>{Math.round(35 + progress * 55)}%</span></div></div>;
  if (uiComponent === 'recording') return <div style={{...dark, background: '#24232A', color: '#F5E9D1', borderRadius: 9, padding: 18}}><strong style={{color: '#E97D76'}}>Recording your voice · 00:10</strong><WaveformHtml progress={progress} /><div style={{margin: '0 auto', width: 38, height: 38, borderRadius: 20, background: '#E66A65'}} /></div>;
  if (uiComponent === 'voice-design') return <div style={dark}>{['Accent', 'Age', 'Pitch', 'Emotion', 'Speed'].map((label, i) => <div key={label} style={{marginTop: 9, display: 'flex', alignItems: 'center', gap: 12}}><span style={{width: 62}}>{label}</span><div style={{height: 6, flex: 1, background: '#CCC8C0', borderRadius: 4}}><div style={{width: `${35 + ((i + 1) * 11) % 50}%`, height: '100%', background: palette.orange, borderRadius: 4, transform: `scaleX(${0.8 + progress * 0.2})`, transformOrigin: 'left'}} /></div></div>)}</div>;
  if (uiComponent === 'script-editor') return <div style={dark}><div style={{padding: 16, minHeight: 104, border: '1px solid #DDD8D0', borderRadius: 8, background: '#FFFDF8', lineHeight: 1.7}}>The words become a voice.<br /><span style={{color: '#A39A94'}}>Cursor active · 84 characters</span></div><div style={{display: 'flex', justifyContent: 'space-between', marginTop: 14, color: '#7C7478'}}><span>English · am_michael</span><span style={{color: palette.orange, fontWeight: 800}}>READY</span></div></div>;
  if (uiComponent === 'generate') return <div style={dark}><div style={{padding: 16, border: '1px solid #DDD8D0', borderRadius: 8}}>Hey, it&apos;s me. This voice costs zero dollars.</div><div style={{display: 'flex', gap: 12, marginTop: 16}}><button style={{flex: 1, padding: 12, border: 0, borderRadius: 8, background: '#F1EEE7'}}>Export WAV</button><button style={{flex: 1, padding: 12, border: 0, borderRadius: 8, background: palette.orange}}>Generate</button></div><WaveformHtml progress={progress} /></div>;
  if (uiComponent === 'caption-sync') return <div style={dark}><strong>Audio timeline</strong><WaveformHtml progress={progress} /><div style={{height: 28, background: '#E8E5DE', borderRadius: 6, position: 'relative'}}><div style={{position: 'absolute', left: `${progress * 80}%`, top: -4, width: 3, height: 36, background: '#3B62DB'}} /></div><div style={{marginTop: 12, color: '#3B62DB'}}>VOICE&nbsp;&nbsp; CAPTIONS&nbsp;&nbsp; SCENES</div></div>;
  if (uiComponent === 'permission') return <div style={{background: '#F5F1E9', borderRadius: 10, padding: 18, color: '#15151B', textAlign: 'center', fontWeight: 700}}>Use only voices you own or have permission to use.<div style={{marginTop: 16, color: '#327B4C', background: '#DDF2E2', padding: 8, borderRadius: 6, fontSize: 12}}>Your own voice · someone who said yes</div></div>;
  return <div style={dark}>The studio explains the idea with a live environment and a relevant object.</div>;
}

function WaveformHtml({progress}: {progress: number}) {
  return <div style={{display: 'flex', gap: 3, alignItems: 'center', height: 54, margin: '14px 0'}}>{Array.from({length: 40}, (_, i) => <i key={i} style={{width: 4, height: 10 + Math.abs(Math.sin(i * 2.1 + progress * 8)) * 36, background: i / 40 < progress ? palette.orange : '#8D8588', borderRadius: 2}} />)}</div>;
}
