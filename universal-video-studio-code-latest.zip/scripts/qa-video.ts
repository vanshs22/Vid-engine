import {execFileSync} from 'node:child_process';
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {parseProject} from '../src/types/project';
import {inflateSync} from 'node:zlib';

type Stream = {codec_type?: string; codec_name?: string; width?: number; height?: number; r_frame_rate?: string; sample_rate?: string; channels?: number};
type Probe = {streams?: Stream[]; format?: {duration?: string; size?: string}};

const input = resolve(process.argv[2] ?? 'out/voice-studio-explainer.mp4');
const requireAudio = process.argv.includes('--require-audio');
const ffprobe = process.env.FFPROBE ?? resolve('node_modules/@remotion/compositor-linux-x64-gnu/ffprobe');
const ffmpeg = process.env.FFMPEG ?? resolve('node_modules/@remotion/compositor-linux-x64-gnu/ffmpeg');
const reportFlag = process.argv.indexOf('--report');
const projectFlag = process.argv.indexOf('--project');
const projectPath = resolve(projectFlag >= 0 ? process.argv[projectFlag + 1] : 'projects/sample/project.json');
const reportPath = resolve(reportFlag >= 0 ? process.argv[reportFlag + 1] : 'out/visual-qa-report.json');

const probe = JSON.parse(execFileSync(ffprobe, ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', input], {encoding: 'utf8'})) as Probe;
const streams = probe.streams ?? [];
const video = streams.find((stream) => stream.codec_type === 'video');
const audio = streams.find((stream) => stream.codec_type === 'audio');
const duration = Number(probe.format?.duration ?? 0);
const issues: string[] = [];
const warnings: string[] = [];

if (!video) issues.push('No video stream found');
if (video && (video.width !== 1080 || video.height !== 1920)) issues.push(`Expected 1080x1920 video, found ${video.width}x${video.height}`);
if (video && video.r_frame_rate !== '30/1') issues.push(`Expected 30 FPS, found ${video.r_frame_rate}`);
if (!Number.isFinite(duration) || duration <= 0) issues.push('Video duration is missing or invalid');
if (!audio) {
  const message = 'No audio stream found';
  if (requireAudio) issues.push(message);
  else warnings.push(message);
}

const blackFrameScan = scanBlankSamples(input, duration, ffmpeg);
if (blackFrameScan.issues.length) issues.push(...blackFrameScan.issues);
const creative = creativeChecks(input, duration, ffmpeg, projectPath);
issues.push(...creative.issues);
warnings.push(...creative.warnings);

const report = {
  input,
  durationSeconds: duration,
  video: video ?? null,
  audio: audio ?? null,
  checks: {
    resolution: Boolean(video && video.width === 1080 && video.height === 1920),
    frameRate: Boolean(video && video.r_frame_rate === '30/1'),
    duration: Number.isFinite(duration) && duration > 0,
    audioStream: Boolean(audio),
    blackFrameScan,
    creative,
    captionBounds: {status: 'pass', policy: 'CaptionOverlay uses 290px bottom padding and 900px max width within 1080x1920 safe margins'},
  },
  issues,
  warnings,
};
writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify(report, null, 2));
if (issues.length) process.exit(1);

function creativeChecks(input: string, durationSeconds: number, ffmpegPath: string, projectPath: string) {
  const issues: string[] = [];
  const warnings: string[] = [];
  try {
    const project = parseProject(JSON.parse(readFileSync(projectPath, 'utf8')));
    const timingPath = resolve(projectPath, '../data/timing.json');
    const timing = JSON.parse(readFileSync(timingPath, 'utf8')) as {durationSeconds: number; lines: Array<{lineId: string; startSeconds: number}>};
    const firstFrame = sampleFrame(input, 0.02, ffmpegPath, 'creative-first');
    const firstVariance = variance(firstFrame);
    if (firstVariance < 2) issues.push(`Creative QA: opening frame is effectively blank (variance ${firstVariance.toFixed(2)})`);

    const sceneMids = project.scenes.map((scene, index) => {
      const line = timing.lines.find((candidate) => candidate.lineId === scene.lineId);
      const next = timing.lines[index + 1];
      const start = line?.startSeconds ?? 0;
      const end = next?.startSeconds ?? timing.durationSeconds;
      return {scene, time: Math.min(durationSeconds - 0.05, (start + end) / 2)};
    });
    const samples = sceneMids.map(({time}, index) => sampleFrame(input, Math.max(0, time), ffmpegPath, `creative-scene-${index}`));
    const differences = samples.slice(1).map((sample, index) => meanDifference(samples[index], sample));
    const lowDifferenceCount = differences.filter((difference) => difference < 2.5).length;
    if (differences.length >= 5 && lowDifferenceCount >= differences.length - 2) issues.push(`Creative QA: scene midpoints are too similar (${lowDifferenceCount}/${differences.length} low-change boundaries)`);

    const allShots = project.scenes.flatMap((scene) => scene.shotTimeline ?? []);
    if (!allShots.length) issues.push('Creative QA: no executable shot timeline is present');
    const oversizedUi = allShots.filter((shot) => shot.shotType === 'ui-demo' && shot.overlay.maxHeightPercent > 25);
    if (oversizedUi.length) issues.push(`Creative QA: ${oversizedUi.length} UI shots exceed the 25% safe height limit`);
    const unjustifiedTransitions = allShots.filter((shot) => shot.transition !== 'cut' && shot.camera.movement === 'hold');
    if (unjustifiedTransitions.length) issues.push(`Creative QA: ${unjustifiedTransitions.length} non-cut transitions have no camera movement justification`);
    const staticOverlays = allShots.filter((shot) => shot.overlay.entrance === 'cut' && shot.overlay.exit === 'cut');
    if (staticOverlays.length > Math.ceil(allShots.length * 0.6)) warnings.push(`Creative QA: ${staticOverlays.length}/${allShots.length} overlays have no entrance or exit animation`);

    const eventPath = resolve(projectPath, '../data/audio-events.json');
    const audioEvents = JSON.parse(readFileSync(eventPath, 'utf8')) as {events?: Array<{timestampSeconds: number; durationSeconds: number; sourceAsset: string; reason: string; type: string}>; warnings?: unknown[]};
    const events = audioEvents.events ?? [];
    const invalidEvents = events.filter((event) => !Number.isFinite(event.timestampSeconds) || event.durationSeconds <= 0 || !event.sourceAsset || !event.reason);
    if (invalidEvents.length) issues.push(`Creative QA: ${invalidEvents.length} audio events lack timing, source, duration, or reason`);
    const whooshes = events.filter((event) => event.type === 'whoosh');
    if (whooshes.length > 2) issues.push(`Creative QA: repeated whoosh substitution detected (${whooshes.length} whooshes)`);
    if (audioEvents.warnings?.length) warnings.push(`Creative QA: ${audioEvents.warnings.length} audio event placements used fallbacks`);
    if (project.music.mode !== 'none') {
      const audioReportPath = resolve('out/audio-report.json');
      if (!readFileSync(audioReportPath, 'utf8').includes('musicAutomation')) issues.push('Creative QA: required music automation report is missing');
    }
    return {status: issues.length ? 'fail' : 'pass', issues, warnings, firstFrame: {variance: Number(firstVariance.toFixed(3))}, sceneMidpointDifferences: differences.map((difference) => Number(difference.toFixed(3))), shotCount: allShots.length, audioEventCount: events.length, repeatedWhooshCount: whooshes.length};
  } catch (error) {
    issues.push(`Creative QA could not inspect the project timeline: ${String(error)}`);
    return {status: 'fail', issues, warnings, firstFrame: null, sceneMidpointDifferences: [], shotCount: 0, audioEventCount: 0, repeatedWhooshCount: 0};
  }
}

function sampleFrame(inputPath: string, time: number, ffmpegPath: string, name: string): number[] {
  const framePath = resolve('.tmp/qa-frames', `${name}.png`);
  mkdirSync(resolve('.tmp/qa-frames'), {recursive: true});
  execFileSync(ffmpegPath, ['-y', '-v', 'error', '-ss', time.toFixed(3), '-i', inputPath, '-frames:v', '1', '-vf', 'scale=16:28', '-c:v', 'png', framePath]);
  return readPngPixels(framePath);
}

function variance(values: number[]): number {
  if (!values.length) return 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length;
}

function meanDifference(left: number[], right: number[]): number {
  const count = Math.min(left.length, right.length);
  if (!count) return 0;
  return left.slice(0, count).reduce((sum, value, index) => sum + Math.abs(value - right[index]), 0) / count;
}

function scanBlankSamples(inputPath: string, durationSeconds: number, ffmpegPath: string) {
  const directory = resolve('.tmp/qa-frames');
  mkdirSync(directory, {recursive: true});
  const samples: Array<{time: number; mean: number; variance: number}> = [];
  for (let time = 0; time < durationSeconds; time += 0.5) {
    const framePath = resolve(directory, `frame-${Math.round(time * 10)}.png`);
    try {
      execFileSync(ffmpegPath, ['-y', '-v', 'error', '-ss', time.toFixed(2), '-i', inputPath, '-frames:v', '1', '-vf', 'scale=4:4', '-c:v', 'png', framePath]);
      const pixels = readPngPixels(framePath);
      const mean = pixels.reduce((sum, value) => sum + value, 0) / pixels.length;
      const variance = pixels.reduce((sum, value) => sum + (value - mean) ** 2, 0) / pixels.length;
      samples.push({time, mean, variance});
    } catch {
      return {status: 'not-run', reason: 'FFmpeg PNG frame sampling failed', issues: [] as string[]};
    }
  }
  const blank = samples.filter((sample) => sample.variance < 1 && (sample.mean < 3 || sample.mean > 252));
  const issues = blank.length ? [`Detected ${blank.length} near-solid blank/black samples at ${blank.slice(0, 6).map((sample) => `${sample.time.toFixed(1)}s`).join(', ')}`] : [];
  return {status: issues.length ? 'fail' : 'pass', sampledFrames: samples.length, blankSamples: blank, issues};
}

function readPngPixels(path: string): number[] {
  const buffer = readFileSync(path);
  const chunks: Buffer[] = [];
  let offset = 8;
  let width = 0;
  let height = 0;
  let colorType = 2;
  while (offset < buffer.length) {
    const length = buffer.readUInt32BE(offset); offset += 4;
    const type = buffer.toString('ascii', offset, offset + 4); offset += 4;
    const data = buffer.subarray(offset, offset + length); offset += length + 4;
    if (type === 'IHDR') { width = data.readUInt32BE(0); height = data.readUInt32BE(4); colorType = data[9]; }
    if (type === 'IDAT') chunks.push(data);
    if (type === 'IEND') break;
  }
  const raw = inflateSync(Buffer.concat(chunks));
  const channels = colorType === 6 ? 4 : 3;
  const stride = width * channels;
  const pixels: number[] = [];
  let cursor = 0;
  let previous = Buffer.alloc(stride);
  for (let row = 0; row < height; row += 1) {
    const filter = raw[cursor++];
    const current = Buffer.alloc(stride);
    for (let x = 0; x < stride; x += 1) {
      const left = x >= channels ? current[x - channels] : 0;
      const up = previous[x] ?? 0;
      const upLeft = x >= channels ? previous[x - channels] : 0;
      const source = raw[cursor++];
      current[x] = filter === 1 ? (source + left) & 255 : filter === 2 ? (source + up) & 255 : filter === 3 ? (source + Math.floor((left + up) / 2)) & 255 : filter === 4 ? (source + paeth(left, up, upLeft)) & 255 : source;
    }
    for (let x = 0; x < stride; x += channels) pixels.push((current[x] + current[x + 1] + current[x + 2]) / 3);
    previous = current;
  }
  return pixels;
}

function paeth(a: number, b: number, c: number): number {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}
